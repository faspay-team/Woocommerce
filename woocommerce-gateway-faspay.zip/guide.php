<<<<<<< .mine
<<<<<<< HEAD
<?php 
require_once '../../../wp-config.php';
require_once '../../../wp-settings.php';
global $woocommerce;

function get_pict($ch){
    $url = get_site_url();

    switch ($ch) {
        case '800':
             echo $url."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/bri.png";
            break;
        case '801':
            echo $url."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/bni.png";
            break;
        case '802':
           echo $url."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/mandiricp.png";
            break;
        case '707':
           echo $url."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/alfamart.png";
            break;
		case '708':
           echo $url."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/danamononline.png";
            break;
		case '701':
           echo $url."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/danamononline.png";
            break;
        case '706':
           echo $url."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/indomaret.png";
            break;
        case '703':
           echo $url."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/mandiricp.png";
            break;
        case '702':
           echo $url."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/bca.png";
            break;
        case '405':
            echo $url."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/bca-klikpay.png";
            break;
        case '408':
           echo $url."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/maybank.png";
            break;
        case '407':
           echo $url."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/maybank.png";
            break;
        case '402':
           echo $url."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/va_permata.png";
            break;
        case '400':
           echo $url."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/mocash.png";
            break;
        case '303':
           echo $url."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/xl_tunai.png";
            break;
        case '711':
           echo $url."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/shoppepayQRIS.png";
            break;
        case '713':
           echo $url."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/shoppepayApp.png";
            break;
        default:
            echo $url."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/faspay-logo.jpg";
            break;
    }
}

function get_guide($ch,$trxid,$merchant,$mid,$currency,$total){
    switch ($ch) {
        case '800':
        ?>
        <button class="accordion">Tata Cara Membayar Melalui ATM BRI<i class="fa fa-arrow-down" style="float: right;"></i></button>
        <div class="panel" style="display: block;">
            <ol>
                <li>Nasabah melakukan pembayaran melalui ATM Bank BRI</li>
                <li>Pilih Menu Transaksi Lain</li>
                <li>Pilih Menu Pembayaran</li>
                <li>Pilih Menu Lainnya</li>
                <li>Pilih Menu BRIVA</li>
                <li>Masukan 16 digit Nomor Virtual Account :<?php echo $trxid ?>.</li>
                <li>Proses Pembayaran (Ya/Tidak)</li>
                <li>Harap Simpan Struk Transaksi yang anda dapatkan</li>
            </ol>
        </div>
        <button class="accordion" >Tata Cara Membayar Melalui Mobile Banking BRI <i class="fa fa-arrow-down" style="float: right;"></i></button>
        <div class="panel">
            <li>Nasabah melakukan pembayaran melalui Mobile/SMS Banking BRI</li>
            <li>Nasabah memilih Menu Pembayaran melalui Menu Mobile/SMS Banking BRI</li>
            <li>Nasabah memilih Menu BRIVA</li>
            <li>Masukan 16 digit Nomor Virtual Account : <?php echo $trxid ?></li>
            <li>Masukan Jumlah Pembayaran sesuai Tagihan</li>
            <li>Masukan PIN Mobile/SMS Banking BRI</li>
            <li>Nasabah mendapat Notifikasi Pembayaran</li>
        </div>
         <button class="accordion" >Tata Cara Membayar Melalui Internet Banking BRI <i class="fa fa-arrow-down" style="float: right;"></i></button>
         <div class="panel">
            <li>Nasabah melakukan pembayaran melalui Internet Banking BRI</li>
            <li>Nasabah memilih Menu Pembayaran</li>
            <li>Nasabah memilih Menu BRIVA</li>
            <li>Masukan Kode Bayar dengan 16 digit Nomor Virtual Account : <?php echo $trxid ?>.</li>
            <li>Masukan Password Internet Banking BRI</li>
            <li>Masukan mToken Internet Banking BRI</li>
            <li>Nasabah mendapat Notifikasi Pembayaran</li>
         </div>
         <button class="accordion" >Tata Cara Membayar Melalui ATM Bank Lain <i class="fa fa-arrow-down" style="float: right;"></i></button>
         <div class="panel">
            <li>Nasabah melakukan pembayaran melalui ATM Bank Lain yang dimiliki Nasabah melalui Menu Transfer Antar Bank</li>
            <li>Masukan Kode Bank Tujuan : BRI (Kode Bank : 002) + Nomor Virtual Account : <?php echo $trxid ?>.</li>
            <li>Masukan Jumlah Pembayaran sesuai Tagihan</li>
            <li>Proses Pembayaran (Ya/Tidak)</li>
            <li>Masukan Password Internet Banking BRI</li>
            <li>Masukan mToken Internet Banking BRI</li>
            <li>Harap Simpan Struk Transaksi yang anda dapatkan</li>
         </div>
        <?php
        break;
        case '303':
        ?>
        <button class="accordion">Tata Cara Membayar <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel" style="display: block;">
        <ol>
        <li>Ketik *123*120# dari handphone Anda, lalu tekan OK/YES</li>
        <li>Setelah muncul menu transaksi XL Tunai, ketik 4 (pilihan Belanja Online)</li>
        <li>Ketik 1 (Lanjut) lalu Kirim</li>
        <li>Masukkan kode merchant <?php echo $merchant ?> <b><u><?php echo $mid ?></u></b> lalu Kirim</li>
        <li>Masukkan Nomor Pesanan sesuai dengan yang tertera pada laman TERIMA KASIH, lalu Kirim.</li>
        <li>Jika pembayaran berhasil, Anda akan menerima notifikasi pembayaran berhasil melalui SMS.</b></li>
        </ol>
    </div>
        <?php
            break;
    	case '802':
    		?> 
    		<button class="accordion">Tata Cara Membayar Melalui ATM</button>
    <div class="panel" style="display: block;">
        <ol>
      	<li>Catat kode pembayaran yang anda dapat</li>
        <li>Gunakan ATM Mandiri untuk menyelesaikan pembayaran</li>
        <li>Masukkan PIN anda</li>
        <li>Pilih 'Bayar/Beli'</li>
        <li>Cari pilihan MULTI PAYMENT</li>
        <li>Masukkan Kode Perusahaan <b>88308</b></li>
        <li>Masukkan Kode Pelanggan <b><?php echo $trxid ?></b></li>
        <li>Masukkan Jumlah Pembayaran sesuai dengan Jumlah Tagihan anda kemudian tekan 'Benar'</li>
        <li>Pilih Tagihan Anda jika sudah sesuai tekan YA</li>
        <li>Konfirmasikan tagihan anda apakah sudah sesuai lalu tekan YA</li>
        <li>Harap Simpan Struk Transaksi yang anda dapatkan</li>
        </ol>
    </div>
    <button class="accordion" >Tata Cara Membayar Melalui Internet Banking Mandiri <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
            <li>Pada Halaman Utama pilih menu BAYAR</li>
            <li>Pilih submenu MULTI PAYMENT</li>
            <li>Cari Penyedia Jasa 'FASPAY'</li>
            <li>Masukkan Kode Pelanggan <b><?php echo $trxid ?></b></li>
            <li>Masukkan Jumlah Pembayaran sesuai dengan Jumlah Tagihan anda</li>
            <li>Pilih LANJUTKAN</li>
            <li>Pilih Tagihan Anda jika sudah sesuai tekan LANJUTKAN</li>
            <li>Transaksi selesai, jika perlu CETAK hasil transaksi anda</li>
    </div>
    <button class="accordion" >Pembayaran melalui ATM Prima <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <ol>
            <li>Masukkan PIN</li>
            <li>Pilih menu TRANSAKSI LAINNYA</li>
            <li>Pilih menu KE REK BANK LAIN</li>
            <li>Masukkan kode sandi Bank Mandiri (008) kemudian tekan BENAR</li>
            <li>Masukkan nomor VIRTUAL ACCOUNT yang tertera pada halaman konfirmasi, dan tekan BENAR</li>
            <li>Masukkan jumlah pembayaran sesuai dengan yang ditagihkan dalam halaman konfirmasi</li>
            <li>Pilih BENAR untuk menyetujui transaksi tersebut</li>
        </ol>
    </div>
    <button class="accordion" >Pembayaran melalui ATM Bersama <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <ol>
            <li>Masukkan PIN</li>
            <li>Pilih menu TRANSAKSI</li>
            <li>Pilih menu KE REK BANK LAIN</li>
            <li>Masukkan kode sandi Bank Mandiri (008) diikuti dengan nomor VIRTUAL ACCOUNT yang tertera pada halaman konfirmasi, dan tekan BENAR</li>
            <li>Masukkan jumlah pembayaran sesuai dengan yang ditagihkan dalam halaman konfirmasi</li>
            <li>Pilih BENAR untuk menyetujui transaksi tersebut</li>
        </ol>
    </div>
    <button class="accordion" >Pembayaran Mandiri Virtual Account dengan Mandiri Online <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <ol>
            <li>Login Mandiri Online dengan memasukkan username dan password</li>
            <li>Pilih menu PEMBAYARAN</li>
            <li>Pilih menu MULTI PAYMENT </li>
            <li>Cari Penyedia Jasa 'FASPAY'</li>
            <li>Masukkan Nomor Virtual Account <b><?php echo $trxid ?></b> dan nominal yang akan dibayarkan, lalu pilih Lanjut</li>
            <li>Setelah muncul tagihan, pilih Konfirmasi</li>
            <li>Masukkan PIN/ challange code token</li>
            <li>Transaksi selesai, simpan bukti bayar anda</li>
        </ol>
    </div>
    		<?php
    		break;
    	case '402':
    		?>
    		<button class="accordion" >Pembayaran Melalui ATM Permata <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel" style="display: block;">
        <ol>
            <li>Masukkan PIN</li>
            <li>Pilih menu TRANSAKSI LAINNYA</li>
            <li>Pilih menu PEMBAYARAN</li>
            <li>Pilih menu PEMBAYARAN LAINNYA</li>
            <li>Pilih menu VIRTUAL ACCOUNT</li>
            <li>Masukkan nomor VIRTUAL ACCOUNT yang tertera pada halaman konfirmasi, dan tekan BENAR</li>
            <li>Pilih rekening yang menjadi sumber dana yang akan didebet, lalu tekan YA untuk konfirmasi transaksi</li>
        </ol>
    </div>

    <button class="accordion" >Pembayaran melalui ATM Prima <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <ol>
            <li>Masukkan PIN</li>
            <li>Pilih menu TRANSAKSI LAINNYA</li>
            <li>Pilih menu KE REK BANK LAIN</li>
            <li>Masukkan kode sandi Bank Permata (013) kemudian tekan BENAR</li>
            <li>Masukkan nomor VIRTUAL ACCOUNT yang tertera pada halaman konfirmasi, dan tekan BENAR</li>
            <li>Masukkan jumlah pembayaran sesuai dengan yang ditagihkan dalam halaman konfirmasi</li>
            <li>Pilih BENAR untuk menyetujui transaksi tersebut</li>
        </ol>
    </div>

    <button class="accordion" >Pembayaran melalui ATM Bersama <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <ol>
            <li>Masukkan PIN</li>
            <li>Pilih menu TRANSAKSI</li>
            <li>Pilih menu KE REK BANK LAIN</li>
            <li>Masukkan kode sandi Bank Permata (013) diikuti dengan nomor VIRTUAL ACCOUNT yang tertera pada halaman konfirmasi, dan tekan BENAR</li>
            <li>Masukkan jumlah pembayaran sesuai dengan yang ditagihkan dalam halaman konfirmasi</li>
            <li>Pilih BENAR untuk menyetujui transaksi tersebut</li>
        </ol>
    </div>

    <button class="accordion" >Pembayaran Melalui Permata Mobile <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <ol>
            <li>Buka aplikasi PermataMobile Internet (Android/iPhone)</li>
            <li>Masukkan User ID & Password</li>
            <li>Pilih Pembayaran Tagihan</li>
            <li>Pilih Virtual Account</li>
            <li>Masukkan 16 digit nomor Virtual Account yang tertera pada halaman konfirmasi</li>
            <li>Masukkan nominal pembayaran sesuai dengan yang ditagihkan</li>
            <li>Muncul Konfirmasi pembayarann</li>
            <li>Masukkan otentikasi transaksi/token</li>
            <li>Transaksi selesai</li>
        </ol>
    </div>

    <button class="accordion" >Pembayaran Melalui Permata Net <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <ol>
            <li>Buka website PermataNet: <a href="https://new.permatanet.com">https://new.permatanet.com</a></li>
            <li>Masukkan User ID & Password</li>
            <li>Pilih Pembayaran Tagihan</li>
            <li>Pilih Virtual Account</li>
            <li>Masukkan 16 digit nomor Virtual Account yang tertera pada halaman konfirmasi</li>
            <li>Masukkan nominal pembayaran sesuai dengan yang ditagihkan</li>
            <li>Muncul Konfirmasi pembayarann</li>
            <li>Masukkan otentikasi transaksi/token</li>
            <li>Transaksi selesai</li>
        </ol>
    </div>
    		<?php
    		case '801':
    			?>
    			<button class="accordion" >Tata Cara Membayar Melalui ATM BNI <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel" style="display: block;">
        <ol>
            <li>Nasabah melakukan pembayaran melalui ATM Bank BNI</li>
            <li>Pilih Menu Lainnya</li>
            <li>Pilih Menu Transfer</li>
            <li>Pilih Menu Rekening Tabungan</li>
            <li>Pilih Menu Ke Rekening BNI</li>
            <li>Masukan 16 digit Nomor Virtual Account <b><?php echo $trxid ?></b></li>
            <li>Masukan Nominal Transfer</li>
            <li>Konfirmasi Pemindahbukuan</li>
            <li>Transaksi Selesai. Harap Simpan Struk Transaksi yang anda dapatkan</li>
        </ol>
    </div>

    <button class="accordion" >Tata Cara Membayar Melalui SMS Banking BNI <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <ol>
            <li>Nasabah melakukan pembayaran melalui SMS Banking BNI</li>
            <li>Pilih Menu Transfer</li>
            <li>Masukan 16 digit Nomor Virtual Account <b><?php echo $trxid ?></b></li>
            <li>Masukan Jumlah Pembayaran. Kemudian Proses</li>
            <li>Akan Muncul Popup dan kemudian Pilih Yes lalu Send</li>
            <li>Anda akan mendapatkan SMS konfirmasi dari BNI</li>
            <li>Reply SMS dengan ketik pin digit ke 2 & 3</li>
            <li>Transaksi Berhasil</li>
        </ol>
        <br>
            Atau bisa juga langsung mengetik sms dan kirim ke 3346 dengan format
        <br>
        <ol>
            <li><b>TRF[SPASI]NOMOR VA BNI[SPASI]NOMINAL</b></li>
            <li>Anda akan mendapatkan SMS konfirmasi dari BNI</li>
            <li>Reply SMS dengan ketik pin digit ke 2 & 3</li>
            <li>Transaksi Berhasil</li>
        </ol>
    </div>

    <button class="accordion" >Internet Banking BNI <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <ol>
            <li>Nasabah melakukan pembayaran melalui Internet Banking BNI</li>
            <li>Ketik alamat <a href="https://ibank.bni.co.id">https://ibank.bni.co.id</a></li>
            <li>Masukkan User ID dan Password</li>
            <li>Klik menu <b>TRANSFER</b> kemudian pilih <b>TAMBAH REKENING FAVORIT</b>. Jika menggunakan Desktop/PC untuk menambah rekening pada menu <b>Transaksi</b> kemudian <b>Atur Rekening Tujuan</b> lalu <b>Tambah Rekening Tujuan</b></li>
            <li>Masukan Nama dan Kode Bayar dengan 16 digit Nomor Virtual Account <b><?php echo $trxid ?></b></li>
            <li>Masukan Kode Otentikasi Token</li>
            <li>Nomor Rekening Tujuan Berhasil Ditambahkan</li>
            <li>Kembali ke menu TRANSFER. Pilih TRANSFER ANTAR REKENING BNI, kemudian pilih rekening tujuan</li>
            <li>Pilih Rekening Debit dan ketik nominal, lalu masukkan kode otentikasi token</li>
            <li>Transfer Anda Telah Berhasil</li>
        </ol>
    </div>

    <button class="accordion" >Mobile Banking BNI <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <ol>
            <li>Akses BNI Mobile Banking dari handphone kemudian masukkan User ID dan Password</li>
            <li>Pilih menu Transfer</li>
            <li>Pilih Antar Rekening BNI kemudian Input Rekening Baru</li>
            <li>Masukkan nomor Rekening Debit</li>
            <li>Masukkan nomor Rekening Tujuan dengan 16 digit Nomor Virtual Account <b><?php echo $trxid ?></b></li>
            <li>Masukkan jumlah pembayaran. Klik Benar</li>
            <li>Konfirmasi transaksi dan masukkan Password Transaksi</li>
            <li>Transaksi Anda Telah Berhasil</li>
        </ol>
    </div>

    <button class="accordion" >ATM Bank Lain <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <ol>
            <li>Nasabah melakukan pembayaran melalui ATM Bank Lain</li>
            <li>Pilih menu Transaksi Lainnya</li>
            <li>Pilih menu Transfer</li>
            <li>Pilih Rekening BNI Lain</li>
            <li>Masukkan Kode Bank BNI (009) dan Pilih Benar</li>
            <li>Masukkan jumlah pembayaran</li>
            <li>Masukkan 16 digit Nomor Virtual Account <b><?php echo $trxid ?></b></li>
            <li>Pilih Rekening yang akan di debit</li>
            <li>Konfirmasi Pembayaran</li>
            <li>Transaksi Selesai. Harap Simpan Struk Transaksi yang anda dapatkan</li>
        </ol>
    </div>
    			<?php
    		break;
    	case '708':
    		?>
    		<button class="accordion" >Pembayaran Melalui ATM Danamon <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel" style="display: block;">
        <b>Pembayaran Melalui ATM Danamon</b>
        <ol>
            <li>Masuk ke menu Pembayaran -> Lainnya -> Virtual Account </li>
            <li>Masukkan 16 digit nomor Virtual Account </li>
            <li>Periksa jumlah tagihan dan konfirmasi pembayaran. </li>
        </ol>
    </div>

    <button class="accordion" >Transfer dari Bank Lain <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <ol>
            <li>Transfer melalui Bank Lain yang tergabung dalam jaringan ATM Bersama, ALTO dan Prima.</li>
            <li>Masukkan kode Bank Danamon (011) dan 16 digit nomor Virtual Account di rekening tujuan.</li>
            <li>Masukkan nominal transfer sesuai tagihan.</li>
        </ol>
    </div>
    		<?php
    		break;
    	case '702':
    		?>
    <button class="accordion" style="display: block;">Tata Cara Membayar Melalui ATM/ANT/SETAR-Setor Tarik <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <b>Langkah-langkah transaksi BCA Virtual Account melalui ATM/ANT/SETAR-Setor Tarik:</b>
        <br>
        <ol>
            <li>Pilih menu Transfer – Ke Rek BCA Virtual Account</li>
            <li>Masukkan Nomor BCA Virtual Account, lalu pilih Benar</li>
            <li>Pilih menu “Ke Rek BCA Virtual Account”</li>
            <li>Layar ATM akan menampilkan konfirmasi transaksi:<br>
                <ul>
                    <li>Pilih Ya bila setuju, atau </li>
                    <li>Masukkan jumlah transfer, lalu pilih Benar. Layar ATM akan kembali menampilkan konfirmasi jumlah pembayaran, pilih Ya bila ingin membayar</li>
                </ul>
            </li>
            <li>Ikuti langkah selanjutnya sampai transaksi selesai</li>
        </ol>
    </div>

    <button class="accordion" >KlikBCA Individu (Full Site dan versi Smartphone) <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <b>Langkah-langkah transaksi BCA Virtual Account melalui KlikBCA Individu: </b>
        <br>
        <ol>
            <li>Pilih Menu Transfer Dana – Transfer ke BCA Virtual Account</li>
            <li>Masukkan nomor BCA Virtual Account, atau pilih Dari Daftar Transfer </li>
            <li>Akan tampil konfirmasi transaksi: <br>
                <ul>
                    <li>Masukkan jumlah nominal transfer dan berita, atau </li>
                    <li>Masukkan berita</li>
                </ul>
            </li>
            <li>Ikuti langkah selanjutnya sampai transaksi selesai </li>
        </ol>
    </div>

    <button class="accordion" >KlikBCA Bisnis <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <b>Langkah-langkah transaksi BCA Virtual Account melalui KlikBCA Bisnis: </b>
        <br>
        <ul>
            <li>Daftar Transfer: <br>
                <ol>
                    <li>Pilih menu Daftar Transfer - Tambah, pilih Ke BCA Virtual Account</li>
                    <li>Masukkan nomor BCA Virtual Account</li>
                    <li>Ikuti langkah selanjutnya sampai selesai </li>
                </ol>
            </li>
            <li>Transfer Dana: <br>
                <ol>
                    <li>Pilih menu Transfer Dana – ke BCA Virtual Account</li>
                    <li>Pilih nomor rekening yang akan didebet dan pilih nomor BCA Virtual Account, lalu lanjut </li>
                    <li>Akan tampil konfirmasi transaksi: <br>
                        <ul>
                            <li>Masukkan jumlah nominal transfer dan berita, atau</li>
                            <li>Masukkan berita</li>
                        </ul>
                    </li>
                    <li>Ikuti langkah selanjutnya sampai transaksi selesai</li>
                </ol>
            </li>
            <li>Otorisasi Transaksi: <br>
                <ul style="list-style-type:none">
                    <li>Pilih menu Transfer Dana - Otorisasi Transaksi Tergantung single/multi otorisasi</li>
                    <li>Untuk Single Otorisasi: <br>
                        <ul>
                            Login User Releaser
                            <li>Tandai transaksi pada tabel Transaksi Yang Belum Diotorisasi, pilih Setuju </li>
                            <li>Ikuti langkah selanjutnya sampai selesai</li>
                        </ul>
                    </li>

                    <li>Untuk Multi Otorisasi: <br>
                        <ul>
                            <li>Login User Approver
                                <ol>
                                    <li>Tandai transaksi pada tabel Approver, pilih Setuju </li>
                                </ol>
                            </li>
                            <li>Login User Releaser
                                <ol>
                                    <li>Tandai transaksi pada tabel Transaksi Yang Belum Diotorisasi, pilih Setuju</li>
                                    <li>Ikuti langkah selanjutnya sampai selesai</li>
                                </ol>
                            </li>
                        </ul>
                    </li>
                </ul>
            </li>
        </ul>
    </div>

    <button class="accordion" >m-BCA (BCA Mobile) <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <b>Langkah-langkah transaksi BCA Virtual Account melalui m-BCA (BCA Mobile):</b>
        <br>
        <ol>
            <li>Pilih m-Transfer</li>
            <li>Pilih Transfer – BCA Virtual Account</li>
            <li>Pilih nomor rekening yang akan didebet</li>
            <li>Masukkan nomor BCA Virtual Account, lalu pilih OK</li>
            <li>Tampil konfirmasi nomor BCA Virtual Account dan rekening pendebetan, lalu Kirim</li>
            <li>Tampil konfirmasi pembayaran, lalu pilih OK <br>
                <ul>
                    <li>Masukkan jumlah nominal transfer dan berita, atau </li>
                    <li>Masukkan berita</li>
                </ul>
            </li>
            <li>Ikuti langkah selanjutnya sampai transaksi selesai </li>
        </ol>
    </div>

    <button class="accordion" >m-BCA (STK) <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <b>Langkah-langkah transaksi BCA Virtual Account melalui m-BCA (STK):</b>
        <br>
        <ol>
            <li>Pilih m-BCA </li>
            <li>Pilih m-Payment</li>
            <li>Pilih Lainnya</li>
            <li>Masukkan TVA pada Nama PT, lalu OK</li>
            <li>Masukkan nomor BCA Virtual Account pada No. Pelanggan, lalu OK</li>
            <li>Masukkan PIN m-BCA, lalu OK</li>
            <li>Pilih Pilih nomor rekening yang akan didebet, lalu lanjut</li>
            <li>Akan muncul konfirmasi pembayaran, lalu pilih OK <br>
                <ul>
                    <li>Masukkan jumlah bayar dan berita, atau </li>
                    <li>Masukkan berita</li>
                </ul>
            </li>
            <li>Ikuti langkah selanjutnya sampai transaksi selesai </li>
        </ol>
    </div>
    		<?php
    		break;
    	case '408':
    		?>
    <button class="accordion" style="display: block;">Pembayaran VA Melalui Mesin ATM Maybank - Menu Pembayaran <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <ol>
            <li>Pilih menu PEMBAYARAN/TOP UP PULSA</li>
            <li>Pilih menu VIRTUAL ACCOUNT</li>
            <li>Masukkan nomor VIRTUAL ACCOUNT yang tertera pada halaman konfirmasi</li>
            <li>Pilih YA untuk menyetujui pembayaran tersebut</li>
        </ol>
    </div>

    <button class="accordion" >Pembayaran VA Melalui Mesin ATM Maybank - Menu Transfer <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <ol>
            <li>Pilih menu TRANSFER</li>
            <li>Pilih menu VIRTUAL ACCOUNT</li>
            <li>Masukkan nomor VIRTUAL ACCOUNT yang tertera pada halaman konfirmasi</li>
            <li>Masukkan jumlah pembayaran sesuai dengan yang ditagihkan dalam halaman konfirmasi</li>
            <li>Silahkan masukkan nomor referensi apabila diperlukan, lalu tekan BENAR</li>
            <li>Pilih YA untuk menyetujui pembayaran tersebut</li>
        </ol>
    </div>

    <button class="accordion" >Pembayaran VA Melalui Maybank Internet Banking <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <ol>
            <li>Silahkan login Internet Banking dari Maybank</li>
            <li>Pilih menu Rekening dan Transaksi</li>
            <li>Kemudian pilih Maybank Virtual Account</li>
            <li>Masukkan nomor rekening dengan nomor Virtual Account Anda : <b><?php echo $trxid ?></b></li>
            <li>Masukkan jumlah pembayaran sesuai dengan yang ditagihkan dalam halaman konfirmasi</li>
            <li>Masukkan SMS Token (TAC) dan klik Setuju</li>
        </ol>
    </div>

    <button class="accordion" >Pembayaran VA Melalui ATM Bank lain <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <ol>
            <li>Pilih menu TRANSFER ANTAR BANK </li>
            <li>Pilih Maybank sebagai bank tujuan atau dengan memasukkan kode bank Maybank “016” diikuti dengan 16 digit nomor VIRTUAL ACCOUNT yang tertera pada halaman konfirmasi</li>
            <li>Masukkan jumlah pembayaran sesuai dengan yang ditagihkan dalam halaman konfirmasi</li>
            <li>Konfirmasikan transaksi anda pada halaman berikutnya. Apabila benar tekan BENAR untuk mengeksekusi transaksi</li>
        </ol>
    </div>
    		<?php
    		case '400':
    			?>
    			<button class="accordion" >Pembayaran Via Aplikasi <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel" style="display: block;">
      <p>
        <img src='<?php echo $srv."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/mocash.png" ; ?>' alt="How">
      </p>
    </div>

    <button class="accordion" >Pembayaran Via SMS <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <center>
            <p>
                Lakukan pembayaran dengan cara mengirim SMS ke 9123, ketik: BAYAR MD (spasi) STORE_ID
                (spasi) AMOUNT (spasi) ORDER_ID (spasi) PIN atau BAYAR MD 1902291 (spasi) 0 (spasi)
                <?php echo $trxid ?> (spasi) (PIN ANDA)
            </p>
        </center>
    </div>
    			<?php
    		break;
    		case '706':
    			?>
    			<button class="accordion" >Tata Cara Membayar Melalui Indomaret <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel" style="display: block;">
        <ol>
            <li>Catat dan simpan kode pembayaran Indomaret anda, yaitu : <b><?php echo $trxid?></b></li>
            <li>Tunjukan kode pembayaran ke kasir Indomaret terdekat dan lakukan pembayaran senilai <b><?php echo $currency." ".number_format($total).".00" ?></b></li>
            <li>Simpan bukti pembayaran yang sewaktu-waktu diperlukan jika terjadi kendala transaksi</li>
        </ol>
    </div>
    			<?php
    			break;
    		case '707':
    			?>
    			<button class="accordion menu-item-object-page" >Pembayaran Melalui Alfamart <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel" style="display: block;">
        <ol>
            <li>Catat dan simpan kode pembayaran Alfamart Anda, yaitu : <?php echo $trxid ?>.</li>
            <li>Datangi kasir Alfamart terdekat dan beritahukan pada kasir bahwa Anda ingin melakukan pembayaran "<?php echo $merchant ?>".</li>
            <li>Beritahukan kode pembayaran Alfamart Anda pada kasir dan silahkan lakukan pembayaran Anda senilai <?php echo $currency." ".number_format($total).".00" ?>.</li>
            <li>Simpan struk pembayaran Anda sebagai tanda bukti pembayaran yang sah.</li>
        </ol>
    </div>
    			<?php
    			break;
    	case '703':
    		?>
    <button class="accordion" style="display: block;">Tata Cara Membayar Melalui ATM <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <ol>
            <li>Catat kode pembayaran yang anda dapat</li>
            <li>Gunakan ATM Mandiri untuk menyelesaikan pembayaran</li>
            <li>Masukkan PIN anda</li>
            <li>Pilih 'Bayar/Beli' lalu pilih 'Lainnya'</li>
            <li>Cari pilihan MULTI PAYMENT</li>
            <li>Masukkan Kode Perusahaan <b><?php echo $mid ?></b></li>
            <li>Masukkan Kode Pelanggan <b><?php echo $trxid ?></b></li>
            <li>Pilih Tagihan Anda jika sudah sesuai tekan YA</li>
            <li>Konfirmasikan tagihan anda apakah sudah sesuai lalu tekan YA</li>
            <li>Harap Simpan Struk Transaksi yang anda dapatkan</li>
        </ol>
    </div>

    <button class="accordion" >Tata Cara Membayar Melalui Mandiri Internet Banking <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <ol>
            <li>Pada Halaman Utama pilih submenu Lain-lain di bawah menu Pembayaran</li>
            <li>Cari Penyedia Jasa 70009 MitraPay</li>
            <li>Isi Nomor Pelanggan yang anda dapatkan</li>
            <li>Masukkan Jumlah Pembayaran sesuai dengan Jumlah Tagihan anda</li>
            <li>Pilih LANJUTKAN</li>
            <li>Transaksi selesai, jika perlu CETAK hasil transaksi anda</li>
        </ol>
    </div>
    		<?php
    		break;
        case '711':
            ?>
                <button class="accordion" style="display: block;">Pembayaran melalui ShopeePay <i class="fa fa-arrow-down" style="float: right;"></i></button>
                <div class="panel">
                    <ol>
                        <li>Buka aplikasi Shopee</li>
                        <li>Klik logo “Scan”</li>
                        <li>Scan QR Code</li>
                        <li>Klik tombol “Bayar Sekarang”</li>
                    </ol>
                </div>

                <button class="accordion" >Pembayaran melalui Mobile Banking atau E-Money lainnya <i class="fa fa-arrow-down" style="float: right;"></i></button>
                <div class="panel">
                    <ol>
                        <li>Buka aplikasi mobile banking atau e-money</li>
                        <li>Klik logo “Pay” atau “Scan”</li>
                        <li>Scan QR Code</li>
                        <li>Klik tombol “Pay” atau “Bayar”</li>
                    </ol>
                </div>
            <?php
            break;
    	default:
    		# code...
    		break;
    }
}
 ?>
=======
<?php 
require_once '../../../wp-config.php';
require_once '../../../wp-settings.php';
global $woocommerce;

function get_pict($ch){
    $url = get_site_url();

    switch ($ch) {
        case '800':
             echo $url."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/bri.png";
            break;
        case '801':
            echo $url."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/bni.png";
            break;
        case '802':
           echo $url."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/mandiricp.png";
            break;
        case '707':
           echo $url."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/alfamart.png";
            break;
		case '708':
           echo $url."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/danamononline.png";
            break;
		case '701':
           echo $url."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/danamononline.png";
            break;
        case '706':
           echo $url."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/indomaret.png";
            break;
        case '703':
           echo $url."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/mandiricp.png";
            break;
        case '702':
           echo $url."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/bca.png";
            break;
        case '405':
            echo $url."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/bca-klikpay.png";
            break;
        case '408':
           echo $url."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/maybank.png";
            break;
        case '407':
           echo $url."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/maybank.png";
            break;
        case '402':
           echo $url."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/va_permata.png";
            break;
        case '400':
           echo $url."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/mocash.png";
            break;
        case '303':
           echo $url."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/xl_tunai.png";
            break;
        case '711':
           echo $url."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/shoppepayQRIS.png";
            break;
        case '713':
           echo $url."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/shoppepayApp.png";
            break;
        default:
            echo $url."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/faspay-logo.jpg";
            break;
    }
}

function get_guide($ch,$trxid,$merchant,$mid,$currency,$total){
    switch ($ch) {
        case '800':
        ?>
        <button class="accordion">Tata Cara Membayar Melalui ATM BRI<i class="fa fa-arrow-down" style="float: right;"></i></button>
        <div class="panel" style="display: block;">
            <ol>
                <li>Nasabah melakukan pembayaran melalui ATM Bank BRI</li>
                <li>Pilih Menu Transaksi Lain</li>
                <li>Pilih Menu Pembayaran</li>
                <li>Pilih Menu Lainnya</li>
                <li>Pilih Menu BRIVA</li>
                <li>Masukan 16 digit Nomor Virtual Account :<?php echo $trxid ?>.</li>
                <li>Proses Pembayaran (Ya/Tidak)</li>
                <li>Harap Simpan Struk Transaksi yang anda dapatkan</li>
            </ol>
        </div>
        <button class="accordion" >Tata Cara Membayar Melalui Mobile Banking BRI <i class="fa fa-arrow-down" style="float: right;"></i></button>
        <div class="panel">
            <li>Nasabah melakukan pembayaran melalui Mobile/SMS Banking BRI</li>
            <li>Nasabah memilih Menu Pembayaran melalui Menu Mobile/SMS Banking BRI</li>
            <li>Nasabah memilih Menu BRIVA</li>
            <li>Masukan 16 digit Nomor Virtual Account : <?php echo $trxid ?></li>
            <li>Masukan Jumlah Pembayaran sesuai Tagihan</li>
            <li>Masukan PIN Mobile/SMS Banking BRI</li>
            <li>Nasabah mendapat Notifikasi Pembayaran</li>
        </div>
         <button class="accordion" >Tata Cara Membayar Melalui Internet Banking BRI <i class="fa fa-arrow-down" style="float: right;"></i></button>
         <div class="panel">
            <li>Nasabah melakukan pembayaran melalui Internet Banking BRI</li>
            <li>Nasabah memilih Menu Pembayaran</li>
            <li>Nasabah memilih Menu BRIVA</li>
            <li>Masukan Kode Bayar dengan 16 digit Nomor Virtual Account : <?php echo $trxid ?>.</li>
            <li>Masukan Password Internet Banking BRI</li>
            <li>Masukan mToken Internet Banking BRI</li>
            <li>Nasabah mendapat Notifikasi Pembayaran</li>
         </div>
         <button class="accordion" >Tata Cara Membayar Melalui ATM Bank Lain <i class="fa fa-arrow-down" style="float: right;"></i></button>
         <div class="panel">
            <li>Nasabah melakukan pembayaran melalui ATM Bank Lain yang dimiliki Nasabah melalui Menu Transfer Antar Bank</li>
            <li>Masukan Kode Bank Tujuan : BRI (Kode Bank : 002) + Nomor Virtual Account : <?php echo $trxid ?>.</li>
            <li>Masukan Jumlah Pembayaran sesuai Tagihan</li>
            <li>Proses Pembayaran (Ya/Tidak)</li>
            <li>Masukan Password Internet Banking BRI</li>
            <li>Masukan mToken Internet Banking BRI</li>
            <li>Harap Simpan Struk Transaksi yang anda dapatkan</li>
         </div>
        <?php
        break;
        case '303':
        ?>
        <button class="accordion">Tata Cara Membayar <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel" style="display: block;">
        <ol>
        <li>Ketik *123*120# dari handphone Anda, lalu tekan OK/YES</li>
        <li>Setelah muncul menu transaksi XL Tunai, ketik 4 (pilihan Belanja Online)</li>
        <li>Ketik 1 (Lanjut) lalu Kirim</li>
        <li>Masukkan kode merchant <?php echo $merchant ?> <b><u><?php echo $mid ?></u></b> lalu Kirim</li>
        <li>Masukkan Nomor Pesanan sesuai dengan yang tertera pada laman TERIMA KASIH, lalu Kirim.</li>
        <li>Jika pembayaran berhasil, Anda akan menerima notifikasi pembayaran berhasil melalui SMS.</b></li>
        </ol>
    </div>
        <?php
            break;
    	case '802':
    		?> 
    		<button class="accordion">Tata Cara Membayar Melalui ATM</button>
    <div class="panel" style="display: block;">
        <ol>
      	<li>Catat kode pembayaran yang anda dapat</li>
        <li>Gunakan ATM Mandiri untuk menyelesaikan pembayaran</li>
        <li>Masukkan PIN anda</li>
        <li>Pilih 'Bayar/Beli'</li>
        <li>Cari pilihan MULTI PAYMENT</li>
        <li>Masukkan Kode Perusahaan <b>88308</b></li>
        <li>Masukkan Kode Pelanggan <b><?php echo $trxid ?></b></li>
        <li>Masukkan Jumlah Pembayaran sesuai dengan Jumlah Tagihan anda kemudian tekan 'Benar'</li>
        <li>Pilih Tagihan Anda jika sudah sesuai tekan YA</li>
        <li>Konfirmasikan tagihan anda apakah sudah sesuai lalu tekan YA</li>
        <li>Harap Simpan Struk Transaksi yang anda dapatkan</li>
        </ol>
    </div>
    <button class="accordion" >Tata Cara Membayar Melalui Internet Banking Mandiri <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
            <li>Pada Halaman Utama pilih menu BAYAR</li>
            <li>Pilih submenu MULTI PAYMENT</li>
            <li>Cari Penyedia Jasa 'FASPAY'</li>
            <li>Masukkan Kode Pelanggan <b><?php echo $trxid ?></b></li>
            <li>Masukkan Jumlah Pembayaran sesuai dengan Jumlah Tagihan anda</li>
            <li>Pilih LANJUTKAN</li>
            <li>Pilih Tagihan Anda jika sudah sesuai tekan LANJUTKAN</li>
            <li>Transaksi selesai, jika perlu CETAK hasil transaksi anda</li>
    </div>
    <button class="accordion" >Pembayaran melalui ATM Prima <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <ol>
            <li>Masukkan PIN</li>
            <li>Pilih menu TRANSAKSI LAINNYA</li>
            <li>Pilih menu KE REK BANK LAIN</li>
            <li>Masukkan kode sandi Bank Mandiri (008) kemudian tekan BENAR</li>
            <li>Masukkan nomor VIRTUAL ACCOUNT yang tertera pada halaman konfirmasi, dan tekan BENAR</li>
            <li>Masukkan jumlah pembayaran sesuai dengan yang ditagihkan dalam halaman konfirmasi</li>
            <li>Pilih BENAR untuk menyetujui transaksi tersebut</li>
        </ol>
    </div>
    <button class="accordion" >Pembayaran melalui ATM Bersama <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <ol>
            <li>Masukkan PIN</li>
            <li>Pilih menu TRANSAKSI</li>
            <li>Pilih menu KE REK BANK LAIN</li>
            <li>Masukkan kode sandi Bank Mandiri (008) diikuti dengan nomor VIRTUAL ACCOUNT yang tertera pada halaman konfirmasi, dan tekan BENAR</li>
            <li>Masukkan jumlah pembayaran sesuai dengan yang ditagihkan dalam halaman konfirmasi</li>
            <li>Pilih BENAR untuk menyetujui transaksi tersebut</li>
        </ol>
    </div>
    <button class="accordion" >Pembayaran Mandiri Virtual Account dengan Mandiri Online <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <ol>
            <li>Login Mandiri Online dengan memasukkan username dan password</li>
            <li>Pilih menu PEMBAYARAN</li>
            <li>Pilih menu MULTI PAYMENT </li>
            <li>Cari Penyedia Jasa 'FASPAY'</li>
            <li>Masukkan Nomor Virtual Account <b><?php echo $trxid ?></b> dan nominal yang akan dibayarkan, lalu pilih Lanjut</li>
            <li>Setelah muncul tagihan, pilih Konfirmasi</li>
            <li>Masukkan PIN/ challange code token</li>
            <li>Transaksi selesai, simpan bukti bayar anda</li>
        </ol>
    </div>
    		<?php
    		break;
    	case '402':
    		?>
    		<button class="accordion" >Pembayaran Melalui ATM Permata <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel" style="display: block;">
        <ol>
            <li>Masukkan PIN</li>
            <li>Pilih menu TRANSAKSI LAINNYA</li>
            <li>Pilih menu PEMBAYARAN</li>
            <li>Pilih menu PEMBAYARAN LAINNYA</li>
            <li>Pilih menu VIRTUAL ACCOUNT</li>
            <li>Masukkan nomor VIRTUAL ACCOUNT yang tertera pada halaman konfirmasi, dan tekan BENAR</li>
            <li>Pilih rekening yang menjadi sumber dana yang akan didebet, lalu tekan YA untuk konfirmasi transaksi</li>
        </ol>
    </div>

    <button class="accordion" >Pembayaran melalui ATM Prima <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <ol>
            <li>Masukkan PIN</li>
            <li>Pilih menu TRANSAKSI LAINNYA</li>
            <li>Pilih menu KE REK BANK LAIN</li>
            <li>Masukkan kode sandi Bank Permata (013) kemudian tekan BENAR</li>
            <li>Masukkan nomor VIRTUAL ACCOUNT yang tertera pada halaman konfirmasi, dan tekan BENAR</li>
            <li>Masukkan jumlah pembayaran sesuai dengan yang ditagihkan dalam halaman konfirmasi</li>
            <li>Pilih BENAR untuk menyetujui transaksi tersebut</li>
        </ol>
    </div>

    <button class="accordion" >Pembayaran melalui ATM Bersama <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <ol>
            <li>Masukkan PIN</li>
            <li>Pilih menu TRANSAKSI</li>
            <li>Pilih menu KE REK BANK LAIN</li>
            <li>Masukkan kode sandi Bank Permata (013) diikuti dengan nomor VIRTUAL ACCOUNT yang tertera pada halaman konfirmasi, dan tekan BENAR</li>
            <li>Masukkan jumlah pembayaran sesuai dengan yang ditagihkan dalam halaman konfirmasi</li>
            <li>Pilih BENAR untuk menyetujui transaksi tersebut</li>
        </ol>
    </div>

    <button class="accordion" >Pembayaran Melalui Permata Mobile <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <ol>
            <li>Buka aplikasi PermataMobile Internet (Android/iPhone)</li>
            <li>Masukkan User ID & Password</li>
            <li>Pilih Pembayaran Tagihan</li>
            <li>Pilih Virtual Account</li>
            <li>Masukkan 16 digit nomor Virtual Account yang tertera pada halaman konfirmasi</li>
            <li>Masukkan nominal pembayaran sesuai dengan yang ditagihkan</li>
            <li>Muncul Konfirmasi pembayarann</li>
            <li>Masukkan otentikasi transaksi/token</li>
            <li>Transaksi selesai</li>
        </ol>
    </div>

    <button class="accordion" >Pembayaran Melalui Permata Net <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <ol>
            <li>Buka website PermataNet: <a href="https://new.permatanet.com">https://new.permatanet.com</a></li>
            <li>Masukkan User ID & Password</li>
            <li>Pilih Pembayaran Tagihan</li>
            <li>Pilih Virtual Account</li>
            <li>Masukkan 16 digit nomor Virtual Account yang tertera pada halaman konfirmasi</li>
            <li>Masukkan nominal pembayaran sesuai dengan yang ditagihkan</li>
            <li>Muncul Konfirmasi pembayarann</li>
            <li>Masukkan otentikasi transaksi/token</li>
            <li>Transaksi selesai</li>
        </ol>
    </div>
    		<?php
    		case '801':
    			?>
    			<button class="accordion" >Tata Cara Membayar Melalui ATM BNI <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel" style="display: block;">
        <ol>
            <li>Nasabah melakukan pembayaran melalui ATM Bank BNI</li>
            <li>Pilih Menu Lainnya</li>
            <li>Pilih Menu Transfer</li>
            <li>Pilih Menu Rekening Tabungan</li>
            <li>Pilih Menu Ke Rekening BNI</li>
            <li>Masukan 16 digit Nomor Virtual Account <b><?php echo $trxid ?></b></li>
            <li>Masukan Nominal Transfer</li>
            <li>Konfirmasi Pemindahbukuan</li>
            <li>Transaksi Selesai. Harap Simpan Struk Transaksi yang anda dapatkan</li>
        </ol>
    </div>

    <button class="accordion" >Tata Cara Membayar Melalui SMS Banking BNI <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <ol>
            <li>Nasabah melakukan pembayaran melalui SMS Banking BNI</li>
            <li>Pilih Menu Transfer</li>
            <li>Masukan 16 digit Nomor Virtual Account <b><?php echo $trxid ?></b></li>
            <li>Masukan Jumlah Pembayaran. Kemudian Proses</li>
            <li>Akan Muncul Popup dan kemudian Pilih Yes lalu Send</li>
            <li>Anda akan mendapatkan SMS konfirmasi dari BNI</li>
            <li>Reply SMS dengan ketik pin digit ke 2 & 3</li>
            <li>Transaksi Berhasil</li>
        </ol>
        <br>
            Atau bisa juga langsung mengetik sms dan kirim ke 3346 dengan format
        <br>
        <ol>
            <li><b>TRF[SPASI]NOMOR VA BNI[SPASI]NOMINAL</b></li>
            <li>Anda akan mendapatkan SMS konfirmasi dari BNI</li>
            <li>Reply SMS dengan ketik pin digit ke 2 & 3</li>
            <li>Transaksi Berhasil</li>
        </ol>
    </div>

    <button class="accordion" >Internet Banking BNI <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <ol>
            <li>Nasabah melakukan pembayaran melalui Internet Banking BNI</li>
            <li>Ketik alamat <a href="https://ibank.bni.co.id">https://ibank.bni.co.id</a></li>
            <li>Masukkan User ID dan Password</li>
            <li>Klik menu <b>TRANSFER</b> kemudian pilih <b>TAMBAH REKENING FAVORIT</b>. Jika menggunakan Desktop/PC untuk menambah rekening pada menu <b>Transaksi</b> kemudian <b>Atur Rekening Tujuan</b> lalu <b>Tambah Rekening Tujuan</b></li>
            <li>Masukan Nama dan Kode Bayar dengan 16 digit Nomor Virtual Account <b><?php echo $trxid ?></b></li>
            <li>Masukan Kode Otentikasi Token</li>
            <li>Nomor Rekening Tujuan Berhasil Ditambahkan</li>
            <li>Kembali ke menu TRANSFER. Pilih TRANSFER ANTAR REKENING BNI, kemudian pilih rekening tujuan</li>
            <li>Pilih Rekening Debit dan ketik nominal, lalu masukkan kode otentikasi token</li>
            <li>Transfer Anda Telah Berhasil</li>
        </ol>
    </div>

    <button class="accordion" >Mobile Banking BNI <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <ol>
            <li>Akses BNI Mobile Banking dari handphone kemudian masukkan User ID dan Password</li>
            <li>Pilih menu Transfer</li>
            <li>Pilih Antar Rekening BNI kemudian Input Rekening Baru</li>
            <li>Masukkan nomor Rekening Debit</li>
            <li>Masukkan nomor Rekening Tujuan dengan 16 digit Nomor Virtual Account <b><?php echo $trxid ?></b></li>
            <li>Masukkan jumlah pembayaran. Klik Benar</li>
            <li>Konfirmasi transaksi dan masukkan Password Transaksi</li>
            <li>Transaksi Anda Telah Berhasil</li>
        </ol>
    </div>

    <button class="accordion" >ATM Bank Lain <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <ol>
            <li>Nasabah melakukan pembayaran melalui ATM Bank Lain</li>
            <li>Pilih menu Transaksi Lainnya</li>
            <li>Pilih menu Transfer</li>
            <li>Pilih Rekening BNI Lain</li>
            <li>Masukkan Kode Bank BNI (009) dan Pilih Benar</li>
            <li>Masukkan jumlah pembayaran</li>
            <li>Masukkan 16 digit Nomor Virtual Account <b><?php echo $trxid ?></b></li>
            <li>Pilih Rekening yang akan di debit</li>
            <li>Konfirmasi Pembayaran</li>
            <li>Transaksi Selesai. Harap Simpan Struk Transaksi yang anda dapatkan</li>
        </ol>
    </div>
    			<?php
    		break;
    	case '708':
    		?>
    		<button class="accordion" >Pembayaran Melalui ATM Danamon <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel" style="display: block;">
        <b>Pembayaran Melalui ATM Danamon</b>
        <ol>
            <li>Masuk ke menu Pembayaran -> Lainnya -> Virtual Account </li>
            <li>Masukkan 16 digit nomor Virtual Account </li>
            <li>Periksa jumlah tagihan dan konfirmasi pembayaran. </li>
        </ol>
    </div>

    <button class="accordion" >Transfer dari Bank Lain <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <ol>
            <li>Transfer melalui Bank Lain yang tergabung dalam jaringan ATM Bersama, ALTO dan Prima.</li>
            <li>Masukkan kode Bank Danamon (011) dan 16 digit nomor Virtual Account di rekening tujuan.</li>
            <li>Masukkan nominal transfer sesuai tagihan.</li>
        </ol>
    </div>
    		<?php
    		break;
    	case '702':
    		?>
    <button class="accordion" style="display: block;">Tata Cara Membayar Melalui ATM/ANT/SETAR-Setor Tarik <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <b>Langkah-langkah transaksi BCA Virtual Account melalui ATM/ANT/SETAR-Setor Tarik:</b>
        <br>
        <ol>
            <li>Pilih menu Transfer – Ke Rek BCA Virtual Account</li>
            <li>Masukkan Nomor BCA Virtual Account, lalu pilih Benar</li>
            <li>Pilih menu “Ke Rek BCA Virtual Account”</li>
            <li>Layar ATM akan menampilkan konfirmasi transaksi:<br>
                <ul>
                    <li>Pilih Ya bila setuju, atau </li>
                    <li>Masukkan jumlah transfer, lalu pilih Benar. Layar ATM akan kembali menampilkan konfirmasi jumlah pembayaran, pilih Ya bila ingin membayar</li>
                </ul>
            </li>
            <li>Ikuti langkah selanjutnya sampai transaksi selesai</li>
        </ol>
    </div>

    <button class="accordion" >KlikBCA Individu (Full Site dan versi Smartphone) <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <b>Langkah-langkah transaksi BCA Virtual Account melalui KlikBCA Individu: </b>
        <br>
        <ol>
            <li>Pilih Menu Transfer Dana – Transfer ke BCA Virtual Account</li>
            <li>Masukkan nomor BCA Virtual Account, atau pilih Dari Daftar Transfer </li>
            <li>Akan tampil konfirmasi transaksi: <br>
                <ul>
                    <li>Masukkan jumlah nominal transfer dan berita, atau </li>
                    <li>Masukkan berita</li>
                </ul>
            </li>
            <li>Ikuti langkah selanjutnya sampai transaksi selesai </li>
        </ol>
    </div>

    <button class="accordion" >KlikBCA Bisnis <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <b>Langkah-langkah transaksi BCA Virtual Account melalui KlikBCA Bisnis: </b>
        <br>
        <ul>
            <li>Daftar Transfer: <br>
                <ol>
                    <li>Pilih menu Daftar Transfer - Tambah, pilih Ke BCA Virtual Account</li>
                    <li>Masukkan nomor BCA Virtual Account</li>
                    <li>Ikuti langkah selanjutnya sampai selesai </li>
                </ol>
            </li>
            <li>Transfer Dana: <br>
                <ol>
                    <li>Pilih menu Transfer Dana – ke BCA Virtual Account</li>
                    <li>Pilih nomor rekening yang akan didebet dan pilih nomor BCA Virtual Account, lalu lanjut </li>
                    <li>Akan tampil konfirmasi transaksi: <br>
                        <ul>
                            <li>Masukkan jumlah nominal transfer dan berita, atau</li>
                            <li>Masukkan berita</li>
                        </ul>
                    </li>
                    <li>Ikuti langkah selanjutnya sampai transaksi selesai</li>
                </ol>
            </li>
            <li>Otorisasi Transaksi: <br>
                <ul style="list-style-type:none">
                    <li>Pilih menu Transfer Dana - Otorisasi Transaksi Tergantung single/multi otorisasi</li>
                    <li>Untuk Single Otorisasi: <br>
                        <ul>
                            Login User Releaser
                            <li>Tandai transaksi pada tabel Transaksi Yang Belum Diotorisasi, pilih Setuju </li>
                            <li>Ikuti langkah selanjutnya sampai selesai</li>
                        </ul>
                    </li>

                    <li>Untuk Multi Otorisasi: <br>
                        <ul>
                            <li>Login User Approver
                                <ol>
                                    <li>Tandai transaksi pada tabel Approver, pilih Setuju </li>
                                </ol>
                            </li>
                            <li>Login User Releaser
                                <ol>
                                    <li>Tandai transaksi pada tabel Transaksi Yang Belum Diotorisasi, pilih Setuju</li>
                                    <li>Ikuti langkah selanjutnya sampai selesai</li>
                                </ol>
                            </li>
                        </ul>
                    </li>
                </ul>
            </li>
        </ul>
    </div>

    <button class="accordion" >m-BCA (BCA Mobile) <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <b>Langkah-langkah transaksi BCA Virtual Account melalui m-BCA (BCA Mobile):</b>
        <br>
        <ol>
            <li>Pilih m-Transfer</li>
            <li>Pilih Transfer – BCA Virtual Account</li>
            <li>Pilih nomor rekening yang akan didebet</li>
            <li>Masukkan nomor BCA Virtual Account, lalu pilih OK</li>
            <li>Tampil konfirmasi nomor BCA Virtual Account dan rekening pendebetan, lalu Kirim</li>
            <li>Tampil konfirmasi pembayaran, lalu pilih OK <br>
                <ul>
                    <li>Masukkan jumlah nominal transfer dan berita, atau </li>
                    <li>Masukkan berita</li>
                </ul>
            </li>
            <li>Ikuti langkah selanjutnya sampai transaksi selesai </li>
        </ol>
    </div>

    <button class="accordion" >m-BCA (STK) <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <b>Langkah-langkah transaksi BCA Virtual Account melalui m-BCA (STK):</b>
        <br>
        <ol>
            <li>Pilih m-BCA </li>
            <li>Pilih m-Payment</li>
            <li>Pilih Lainnya</li>
            <li>Masukkan TVA pada Nama PT, lalu OK</li>
            <li>Masukkan nomor BCA Virtual Account pada No. Pelanggan, lalu OK</li>
            <li>Masukkan PIN m-BCA, lalu OK</li>
            <li>Pilih Pilih nomor rekening yang akan didebet, lalu lanjut</li>
            <li>Akan muncul konfirmasi pembayaran, lalu pilih OK <br>
                <ul>
                    <li>Masukkan jumlah bayar dan berita, atau </li>
                    <li>Masukkan berita</li>
                </ul>
            </li>
            <li>Ikuti langkah selanjutnya sampai transaksi selesai </li>
        </ol>
    </div>
    		<?php
    		break;
    	case '408':
    		?>
    <button class="accordion" style="display: block;">Pembayaran VA Melalui Mesin ATM Maybank - Menu Pembayaran <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <ol>
            <li>Pilih menu PEMBAYARAN/TOP UP PULSA</li>
            <li>Pilih menu VIRTUAL ACCOUNT</li>
            <li>Masukkan nomor VIRTUAL ACCOUNT yang tertera pada halaman konfirmasi</li>
            <li>Pilih YA untuk menyetujui pembayaran tersebut</li>
        </ol>
    </div>

    <button class="accordion" >Pembayaran VA Melalui Mesin ATM Maybank - Menu Transfer <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <ol>
            <li>Pilih menu TRANSFER</li>
            <li>Pilih menu VIRTUAL ACCOUNT</li>
            <li>Masukkan nomor VIRTUAL ACCOUNT yang tertera pada halaman konfirmasi</li>
            <li>Masukkan jumlah pembayaran sesuai dengan yang ditagihkan dalam halaman konfirmasi</li>
            <li>Silahkan masukkan nomor referensi apabila diperlukan, lalu tekan BENAR</li>
            <li>Pilih YA untuk menyetujui pembayaran tersebut</li>
        </ol>
    </div>

    <button class="accordion" >Pembayaran VA Melalui Maybank Internet Banking <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <ol>
            <li>Silahkan login Internet Banking dari Maybank</li>
            <li>Pilih menu Rekening dan Transaksi</li>
            <li>Kemudian pilih Maybank Virtual Account</li>
            <li>Masukkan nomor rekening dengan nomor Virtual Account Anda : <b><?php echo $trxid ?></b></li>
            <li>Masukkan jumlah pembayaran sesuai dengan yang ditagihkan dalam halaman konfirmasi</li>
            <li>Masukkan SMS Token (TAC) dan klik Setuju</li>
        </ol>
    </div>

    <button class="accordion" >Pembayaran VA Melalui ATM Bank lain <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <ol>
            <li>Pilih menu TRANSFER ANTAR BANK </li>
            <li>Pilih Maybank sebagai bank tujuan atau dengan memasukkan kode bank Maybank “016” diikuti dengan 16 digit nomor VIRTUAL ACCOUNT yang tertera pada halaman konfirmasi</li>
            <li>Masukkan jumlah pembayaran sesuai dengan yang ditagihkan dalam halaman konfirmasi</li>
            <li>Konfirmasikan transaksi anda pada halaman berikutnya. Apabila benar tekan BENAR untuk mengeksekusi transaksi</li>
        </ol>
    </div>
    		<?php
    		case '400':
    			?>
    			<button class="accordion" >Pembayaran Via Aplikasi <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel" style="display: block;">
      <p>
        <img src='<?php echo $srv."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/mocash.png" ; ?>' alt="How">
      </p>
    </div>

    <button class="accordion" >Pembayaran Via SMS <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <center>
            <p>
                Lakukan pembayaran dengan cara mengirim SMS ke 9123, ketik: BAYAR MD (spasi) STORE_ID
                (spasi) AMOUNT (spasi) ORDER_ID (spasi) PIN atau BAYAR MD 1902291 (spasi) 0 (spasi)
                <?php echo $trxid ?> (spasi) (PIN ANDA)
            </p>
        </center>
    </div>
    			<?php
    		break;
    		case '706':
    			?>
    			<button class="accordion" >Tata Cara Membayar Melalui Indomaret <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel" style="display: block;">
        <ol>
            <li>Catat dan simpan kode pembayaran Indomaret anda, yaitu : <b><?php echo $trxid?></b></li>
            <li>Tunjukan kode pembayaran ke kasir Indomaret terdekat dan lakukan pembayaran senilai <b><?php echo $currency." ".number_format($total).".00" ?></b></li>
            <li>Simpan bukti pembayaran yang sewaktu-waktu diperlukan jika terjadi kendala transaksi</li>
        </ol>
    </div>
    			<?php
    			break;
    		case '707':
    			?>
    			<button class="accordion menu-item-object-page" >Pembayaran Melalui Alfamart <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel" style="display: block;">
        <ol>
            <li>Catat dan simpan kode pembayaran Alfamart Anda, yaitu : <?php echo $trxid ?>.</li>
            <li>Datangi kasir Alfamart terdekat dan beritahukan pada kasir bahwa Anda ingin melakukan pembayaran "<?php echo $merchant ?>".</li>
            <li>Beritahukan kode pembayaran Alfamart Anda pada kasir dan silahkan lakukan pembayaran Anda senilai <?php echo $currency." ".number_format($total).".00" ?>.</li>
            <li>Simpan struk pembayaran Anda sebagai tanda bukti pembayaran yang sah.</li>
        </ol>
    </div>
    			<?php
    			break;
    	case '703':
    		?>
    <button class="accordion" style="display: block;">Tata Cara Membayar Melalui ATM <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <ol>
            <li>Catat kode pembayaran yang anda dapat</li>
            <li>Gunakan ATM Mandiri untuk menyelesaikan pembayaran</li>
            <li>Masukkan PIN anda</li>
            <li>Pilih 'Bayar/Beli' lalu pilih 'Lainnya'</li>
            <li>Cari pilihan MULTI PAYMENT</li>
            <li>Masukkan Kode Perusahaan <b><?php echo $mid ?></b></li>
            <li>Masukkan Kode Pelanggan <b><?php echo $trxid ?></b></li>
            <li>Pilih Tagihan Anda jika sudah sesuai tekan YA</li>
            <li>Konfirmasikan tagihan anda apakah sudah sesuai lalu tekan YA</li>
            <li>Harap Simpan Struk Transaksi yang anda dapatkan</li>
        </ol>
    </div>

    <button class="accordion" >Tata Cara Membayar Melalui Mandiri Internet Banking <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <ol>
            <li>Pada Halaman Utama pilih submenu Lain-lain di bawah menu Pembayaran</li>
            <li>Cari Penyedia Jasa 70009 MitraPay</li>
            <li>Isi Nomor Pelanggan yang anda dapatkan</li>
            <li>Masukkan Jumlah Pembayaran sesuai dengan Jumlah Tagihan anda</li>
            <li>Pilih LANJUTKAN</li>
            <li>Transaksi selesai, jika perlu CETAK hasil transaksi anda</li>
        </ol>
    </div>
    		<?php
    		break;
        case '711':
            ?>
                <button class="accordion" style="display: block;">Pembayaran melalui ShopeePay <i class="fa fa-arrow-down" style="float: right;"></i></button>
                <div class="panel">
                    <ol>
                        <li>Buka aplikasi Shopee</li>
                        <li>Klik logo “Scan”</li>
                        <li>Scan QR Code</li>
                        <li>Klik tombol “Bayar Sekarang”</li>
                    </ol>
                </div>

                <button class="accordion" >Pembayaran melalui Mobile Banking atau E-Money lainnya <i class="fa fa-arrow-down" style="float: right;"></i></button>
                <div class="panel">
                    <ol>
                        <li>Buka aplikasi mobile banking atau e-money</li>
                        <li>Klik logo “Pay” atau “Scan”</li>
                        <li>Scan QR Code</li>
                        <li>Klik tombol “Pay” atau “Bayar”</li>
                    </ol>
                </div>
            <?php
            break;
    	default:
    		# code...
    		break;
    }
}
 ?>
>>>>>>> abcc252f4192e153f4fa1de777e9b1a8abd69874
||||||| .r40
<?php 
require_once '../../../wp-config.php';
require_once '../../../wp-settings.php';
global $woocommerce;

function get_pict($ch){
    $url = get_site_url();

    switch ($ch) {
        case '800':
             echo $url."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/bri.png";
            break;
        case '801':
            echo $url."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/bni.png";
            break;
        case '802':
           echo $url."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/mandiricp.png";
            break;
        case '707':
           echo $url."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/alfamart.png";
            break;
		case '708':
           echo $url."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/danamononline.png";
            break;
		case '701':
           echo $url."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/danamononline.png";
            break;
        case '706':
           echo $url."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/indomaret.png";
            break;
        case '703':
           echo $url."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/mandiricp.png";
            break;
        case '702':
           echo $url."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/bca.png";
            break;
        case '405':
            echo $url."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/bca-klikpay.png";
            break;
        case '408':
           echo $url."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/maybank.png";
            break;
        case '407':
           echo $url."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/maybank.png";
            break;
        case '402':
           echo $url."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/va_permata.png";
            break;
        case '400':
           echo $url."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/mocash.png";
            break;
        case '303':
           echo $url."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/xl_tunai.png";
            break;
        case '711':
           echo $url."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/shoppepayQRIS.png";
            break;
        case '713':
           echo $url."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/shoppepayApp.png";
            break;
        default:
            echo $url."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/faspay-logo.jpg";
            break;
    }
}

function get_guide($ch,$trxid,$merchant,$mid,$currency,$total){
    switch ($ch) {
        case '800':
        ?>
        <button class="accordion">Tata Cara Membayar Melalui ATM BRI<i class="fa fa-arrow-down" style="float: right;"></i></button>
        <div class="panel" style="display: block;">
            <ol>
                <li>Nasabah melakukan pembayaran melalui ATM Bank BRI</li>
                <li>Pilih Menu Transaksi Lain</li>
                <li>Pilih Menu Pembayaran</li>
                <li>Pilih Menu Lainnya</li>
                <li>Pilih Menu BRIVA</li>
                <li>Masukan 16 digit Nomor Virtual Account :<?php echo $trxid ?>.</li>
                <li>Proses Pembayaran (Ya/Tidak)</li>
                <li>Harap Simpan Struk Transaksi yang anda dapatkan</li>
            </ol>
        </div>
        <button class="accordion" >Tata Cara Membayar Melalui Mobile Banking BRI <i class="fa fa-arrow-down" style="float: right;"></i></button>
        <div class="panel">
            <li>Nasabah melakukan pembayaran melalui Mobile/SMS Banking BRI</li>
            <li>Nasabah memilih Menu Pembayaran melalui Menu Mobile/SMS Banking BRI</li>
            <li>Nasabah memilih Menu BRIVA</li>
            <li>Masukan 16 digit Nomor Virtual Account : <?php echo $trxid ?></li>
            <li>Masukan Jumlah Pembayaran sesuai Tagihan</li>
            <li>Masukan PIN Mobile/SMS Banking BRI</li>
            <li>Nasabah mendapat Notifikasi Pembayaran</li>
        </div>
         <button class="accordion" >Tata Cara Membayar Melalui Internet Banking BRI <i class="fa fa-arrow-down" style="float: right;"></i></button>
         <div class="panel">
            <li>Nasabah melakukan pembayaran melalui Internet Banking BRI</li>
            <li>Nasabah memilih Menu Pembayaran</li>
            <li>Nasabah memilih Menu BRIVA</li>
            <li>Masukan Kode Bayar dengan 16 digit Nomor Virtual Account : <?php echo $trxid ?>.</li>
            <li>Masukan Password Internet Banking BRI</li>
            <li>Masukan mToken Internet Banking BRI</li>
            <li>Nasabah mendapat Notifikasi Pembayaran</li>
         </div>
         <button class="accordion" >Tata Cara Membayar Melalui ATM Bank Lain <i class="fa fa-arrow-down" style="float: right;"></i></button>
         <div class="panel">
            <li>Nasabah melakukan pembayaran melalui ATM Bank Lain yang dimiliki Nasabah melalui Menu Transfer Antar Bank</li>
            <li>Masukan Kode Bank Tujuan : BRI (Kode Bank : 002) + Nomor Virtual Account : <?php echo $trxid ?>.</li>
            <li>Masukan Jumlah Pembayaran sesuai Tagihan</li>
            <li>Proses Pembayaran (Ya/Tidak)</li>
            <li>Masukan Password Internet Banking BRI</li>
            <li>Masukan mToken Internet Banking BRI</li>
            <li>Harap Simpan Struk Transaksi yang anda dapatkan</li>
         </div>
        <?php
        break;
        case '303':
        ?>
        <button class="accordion">Tata Cara Membayar <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel" style="display: block;">
        <ol>
        <li>Ketik *123*120# dari handphone Anda, lalu tekan OK/YES</li>
        <li>Setelah muncul menu transaksi XL Tunai, ketik 4 (pilihan Belanja Online)</li>
        <li>Ketik 1 (Lanjut) lalu Kirim</li>
        <li>Masukkan kode merchant <?php echo $merchant ?> <b><u><?php echo $mid ?></u></b> lalu Kirim</li>
        <li>Masukkan Nomor Pesanan sesuai dengan yang tertera pada laman TERIMA KASIH, lalu Kirim.</li>
        <li>Jika pembayaran berhasil, Anda akan menerima notifikasi pembayaran berhasil melalui SMS.</b></li>
        </ol>
    </div>
        <?php
            break;
    	case '802':
    		?> 
    		<button class="accordion">Tata Cara Membayar Melalui ATM</button>
    <div class="panel" style="display: block;">
        <ol>
      	<li>Catat kode pembayaran yang anda dapat</li>
        <li>Gunakan ATM Mandiri untuk menyelesaikan pembayaran</li>
        <li>Masukkan PIN anda</li>
        <li>Pilih 'Bayar/Beli'</li>
        <li>Cari pilihan MULTI PAYMENT</li>
        <li>Masukkan Kode Perusahaan <b>88308</b></li>
        <li>Masukkan Kode Pelanggan <b><?php echo $trxid ?></b></li>
        <li>Masukkan Jumlah Pembayaran sesuai dengan Jumlah Tagihan anda kemudian tekan 'Benar'</li>
        <li>Pilih Tagihan Anda jika sudah sesuai tekan YA</li>
        <li>Konfirmasikan tagihan anda apakah sudah sesuai lalu tekan YA</li>
        <li>Harap Simpan Struk Transaksi yang anda dapatkan</li>
        </ol>
    </div>
    <button class="accordion" >Tata Cara Membayar Melalui Internet Banking Mandiri <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
            <li>Pada Halaman Utama pilih menu BAYAR</li>
            <li>Pilih submenu MULTI PAYMENT</li>
            <li>Cari Penyedia Jasa 'FASPAY'</li>
            <li>Masukkan Kode Pelanggan <b><?php echo $trxid ?></b></li>
            <li>Masukkan Jumlah Pembayaran sesuai dengan Jumlah Tagihan anda</li>
            <li>Pilih LANJUTKAN</li>
            <li>Pilih Tagihan Anda jika sudah sesuai tekan LANJUTKAN</li>
            <li>Transaksi selesai, jika perlu CETAK hasil transaksi anda</li>
    </div>
    <button class="accordion" >Pembayaran melalui ATM Prima <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <ol>
            <li>Masukkan PIN</li>
            <li>Pilih menu TRANSAKSI LAINNYA</li>
            <li>Pilih menu KE REK BANK LAIN</li>
            <li>Masukkan kode sandi Bank Mandiri (008) kemudian tekan BENAR</li>
            <li>Masukkan nomor VIRTUAL ACCOUNT yang tertera pada halaman konfirmasi, dan tekan BENAR</li>
            <li>Masukkan jumlah pembayaran sesuai dengan yang ditagihkan dalam halaman konfirmasi</li>
            <li>Pilih BENAR untuk menyetujui transaksi tersebut</li>
        </ol>
    </div>
    <button class="accordion" >Pembayaran melalui ATM Bersama <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <ol>
            <li>Masukkan PIN</li>
            <li>Pilih menu TRANSAKSI</li>
            <li>Pilih menu KE REK BANK LAIN</li>
            <li>Masukkan kode sandi Bank Mandiri (008) diikuti dengan nomor VIRTUAL ACCOUNT yang tertera pada halaman konfirmasi, dan tekan BENAR</li>
            <li>Masukkan jumlah pembayaran sesuai dengan yang ditagihkan dalam halaman konfirmasi</li>
            <li>Pilih BENAR untuk menyetujui transaksi tersebut</li>
        </ol>
    </div>
    <button class="accordion" >Pembayaran Mandiri Virtual Account dengan Mandiri Online <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <ol>
            <li>Login Mandiri Online dengan memasukkan username dan password</li>
            <li>Pilih menu PEMBAYARAN</li>
            <li>Pilih menu MULTI PAYMENT </li>
            <li>Cari Penyedia Jasa 'FASPAY'</li>
            <li>Masukkan Nomor Virtual Account <b><?php echo $trxid ?></b> dan nominal yang akan dibayarkan, lalu pilih Lanjut</li>
            <li>Setelah muncul tagihan, pilih Konfirmasi</li>
            <li>Masukkan PIN/ challange code token</li>
            <li>Transaksi selesai, simpan bukti bayar anda</li>
        </ol>
    </div>
    		<?php
    		break;
    	case '402':
    		?>
    		<button class="accordion" >Pembayaran Melalui ATM Permata <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel" style="display: block;">
        <ol>
            <li>Masukkan PIN</li>
            <li>Pilih menu TRANSAKSI LAINNYA</li>
            <li>Pilih menu PEMBAYARAN</li>
            <li>Pilih menu PEMBAYARAN LAINNYA</li>
            <li>Pilih menu VIRTUAL ACCOUNT</li>
            <li>Masukkan nomor VIRTUAL ACCOUNT yang tertera pada halaman konfirmasi, dan tekan BENAR</li>
            <li>Pilih rekening yang menjadi sumber dana yang akan didebet, lalu tekan YA untuk konfirmasi transaksi</li>
        </ol>
    </div>

    <button class="accordion" >Pembayaran melalui ATM Prima <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <ol>
            <li>Masukkan PIN</li>
            <li>Pilih menu TRANSAKSI LAINNYA</li>
            <li>Pilih menu KE REK BANK LAIN</li>
            <li>Masukkan kode sandi Bank Permata (013) kemudian tekan BENAR</li>
            <li>Masukkan nomor VIRTUAL ACCOUNT yang tertera pada halaman konfirmasi, dan tekan BENAR</li>
            <li>Masukkan jumlah pembayaran sesuai dengan yang ditagihkan dalam halaman konfirmasi</li>
            <li>Pilih BENAR untuk menyetujui transaksi tersebut</li>
        </ol>
    </div>

    <button class="accordion" >Pembayaran melalui ATM Bersama <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <ol>
            <li>Masukkan PIN</li>
            <li>Pilih menu TRANSAKSI</li>
            <li>Pilih menu KE REK BANK LAIN</li>
            <li>Masukkan kode sandi Bank Permata (013) diikuti dengan nomor VIRTUAL ACCOUNT yang tertera pada halaman konfirmasi, dan tekan BENAR</li>
            <li>Masukkan jumlah pembayaran sesuai dengan yang ditagihkan dalam halaman konfirmasi</li>
            <li>Pilih BENAR untuk menyetujui transaksi tersebut</li>
        </ol>
    </div>

    <button class="accordion" >Pembayaran Melalui Permata Mobile <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <ol>
            <li>Buka aplikasi PermataMobile Internet (Android/iPhone)</li>
            <li>Masukkan User ID & Password</li>
            <li>Pilih Pembayaran Tagihan</li>
            <li>Pilih Virtual Account</li>
            <li>Masukkan 16 digit nomor Virtual Account yang tertera pada halaman konfirmasi</li>
            <li>Masukkan nominal pembayaran sesuai dengan yang ditagihkan</li>
            <li>Muncul Konfirmasi pembayarann</li>
            <li>Masukkan otentikasi transaksi/token</li>
            <li>Transaksi selesai</li>
        </ol>
    </div>

    <button class="accordion" >Pembayaran Melalui Permata Net <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <ol>
            <li>Buka website PermataNet: <a href="https://new.permatanet.com">https://new.permatanet.com</a></li>
            <li>Masukkan User ID & Password</li>
            <li>Pilih Pembayaran Tagihan</li>
            <li>Pilih Virtual Account</li>
            <li>Masukkan 16 digit nomor Virtual Account yang tertera pada halaman konfirmasi</li>
            <li>Masukkan nominal pembayaran sesuai dengan yang ditagihkan</li>
            <li>Muncul Konfirmasi pembayarann</li>
            <li>Masukkan otentikasi transaksi/token</li>
            <li>Transaksi selesai</li>
        </ol>
    </div>
    		<?php
    		case '801':
    			?>
    			<button class="accordion" >Tata Cara Membayar Melalui ATM BNI <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel" style="display: block;">
        <ol>
            <li>Nasabah melakukan pembayaran melalui ATM Bank BNI</li>
            <li>Pilih Menu Lainnya</li>
            <li>Pilih Menu Transfer</li>
            <li>Pilih Menu Rekening Tabungan</li>
            <li>Pilih Menu Ke Rekening BNI</li>
            <li>Masukan 16 digit Nomor Virtual Account <b><?php echo $trxid ?></b></li>
            <li>Masukan Nominal Transfer</li>
            <li>Konfirmasi Pemindahbukuan</li>
            <li>Transaksi Selesai. Harap Simpan Struk Transaksi yang anda dapatkan</li>
        </ol>
    </div>

    <button class="accordion" >Tata Cara Membayar Melalui SMS Banking BNI <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <ol>
            <li>Nasabah melakukan pembayaran melalui SMS Banking BNI</li>
            <li>Pilih Menu Transfer</li>
            <li>Masukan 16 digit Nomor Virtual Account <b><?php echo $trxid ?></b></li>
            <li>Masukan Jumlah Pembayaran. Kemudian Proses</li>
            <li>Akan Muncul Popup dan kemudian Pilih Yes lalu Send</li>
            <li>Anda akan mendapatkan SMS konfirmasi dari BNI</li>
            <li>Reply SMS dengan ketik pin digit ke 2 & 3</li>
            <li>Transaksi Berhasil</li>
        </ol>
        <br>
            Atau bisa juga langsung mengetik sms dan kirim ke 3346 dengan format
        <br>
        <ol>
            <li><b>TRF[SPASI]NOMOR VA BNI[SPASI]NOMINAL</b></li>
            <li>Anda akan mendapatkan SMS konfirmasi dari BNI</li>
            <li>Reply SMS dengan ketik pin digit ke 2 & 3</li>
            <li>Transaksi Berhasil</li>
        </ol>
    </div>

    <button class="accordion" >Internet Banking BNI <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <ol>
            <li>Nasabah melakukan pembayaran melalui Internet Banking BNI</li>
            <li>Ketik alamat <a href="https://ibank.bni.co.id">https://ibank.bni.co.id</a></li>
            <li>Masukkan User ID dan Password</li>
            <li>Klik menu <b>TRANSFER</b> kemudian pilih <b>TAMBAH REKENING FAVORIT</b>. Jika menggunakan Desktop/PC untuk menambah rekening pada menu <b>Transaksi</b> kemudian <b>Atur Rekening Tujuan</b> lalu <b>Tambah Rekening Tujuan</b></li>
            <li>Masukan Nama dan Kode Bayar dengan 16 digit Nomor Virtual Account <b><?php echo $trxid ?></b></li>
            <li>Masukan Kode Otentikasi Token</li>
            <li>Nomor Rekening Tujuan Berhasil Ditambahkan</li>
            <li>Kembali ke menu TRANSFER. Pilih TRANSFER ANTAR REKENING BNI, kemudian pilih rekening tujuan</li>
            <li>Pilih Rekening Debit dan ketik nominal, lalu masukkan kode otentikasi token</li>
            <li>Transfer Anda Telah Berhasil</li>
        </ol>
    </div>

    <button class="accordion" >Mobile Banking BNI <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <ol>
            <li>Akses BNI Mobile Banking dari handphone kemudian masukkan User ID dan Password</li>
            <li>Pilih menu Transfer</li>
            <li>Pilih Antar Rekening BNI kemudian Input Rekening Baru</li>
            <li>Masukkan nomor Rekening Debit</li>
            <li>Masukkan nomor Rekening Tujuan dengan 16 digit Nomor Virtual Account <b><?php echo $trxid ?></b></li>
            <li>Masukkan jumlah pembayaran. Klik Benar</li>
            <li>Konfirmasi transaksi dan masukkan Password Transaksi</li>
            <li>Transaksi Anda Telah Berhasil</li>
        </ol>
    </div>

    <button class="accordion" >ATM Bank Lain <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <ol>
            <li>Nasabah melakukan pembayaran melalui ATM Bank Lain</li>
            <li>Pilih menu Transaksi Lainnya</li>
            <li>Pilih menu Transfer</li>
            <li>Pilih Rekening BNI Lain</li>
            <li>Masukkan Kode Bank BNI (009) dan Pilih Benar</li>
            <li>Masukkan jumlah pembayaran</li>
            <li>Masukkan 16 digit Nomor Virtual Account <b><?php echo $trxid ?></b></li>
            <li>Pilih Rekening yang akan di debit</li>
            <li>Konfirmasi Pembayaran</li>
            <li>Transaksi Selesai. Harap Simpan Struk Transaksi yang anda dapatkan</li>
        </ol>
    </div>
    			<?php
    		break;
    	case '708':
    		?>
    		<button class="accordion" >Pembayaran Melalui ATM Danamon <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel" style="display: block;">
        <b>Pembayaran Melalui ATM Danamon</b>
        <ol>
            <li>Masuk ke menu Pembayaran -> Lainnya -> Virtual Account </li>
            <li>Masukkan 16 digit nomor Virtual Account </li>
            <li>Periksa jumlah tagihan dan konfirmasi pembayaran. </li>
        </ol>
    </div>

    <button class="accordion" >Transfer dari Bank Lain <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <ol>
            <li>Transfer melalui Bank Lain yang tergabung dalam jaringan ATM Bersama, ALTO dan Prima.</li>
            <li>Masukkan kode Bank Danamon (011) dan 16 digit nomor Virtual Account di rekening tujuan.</li>
            <li>Masukkan nominal transfer sesuai tagihan.</li>
        </ol>
    </div>
    		<?php
    		break;
    	case '702':
    		?>
    <button class="accordion" style="display: block;">Tata Cara Membayar Melalui ATM/ANT/SETAR-Setor Tarik <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <b>Langkah-langkah transaksi BCA Virtual Account melalui ATM/ANT/SETAR-Setor Tarik:</b>
        <br>
        <ol>
            <li>Pilih menu Transfer – Ke Rek BCA Virtual Account</li>
            <li>Masukkan Nomor BCA Virtual Account, lalu pilih Benar</li>
            <li>Pilih menu “Ke Rek BCA Virtual Account”</li>
            <li>Layar ATM akan menampilkan konfirmasi transaksi:<br>
                <ul>
                    <li>Pilih Ya bila setuju, atau </li>
                    <li>Masukkan jumlah transfer, lalu pilih Benar. Layar ATM akan kembali menampilkan konfirmasi jumlah pembayaran, pilih Ya bila ingin membayar</li>
                </ul>
            </li>
            <li>Ikuti langkah selanjutnya sampai transaksi selesai</li>
        </ol>
    </div>

    <button class="accordion" >KlikBCA Individu (Full Site dan versi Smartphone) <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <b>Langkah-langkah transaksi BCA Virtual Account melalui KlikBCA Individu: </b>
        <br>
        <ol>
            <li>Pilih Menu Transfer Dana – Transfer ke BCA Virtual Account</li>
            <li>Masukkan nomor BCA Virtual Account, atau pilih Dari Daftar Transfer </li>
            <li>Akan tampil konfirmasi transaksi: <br>
                <ul>
                    <li>Masukkan jumlah nominal transfer dan berita, atau </li>
                    <li>Masukkan berita</li>
                </ul>
            </li>
            <li>Ikuti langkah selanjutnya sampai transaksi selesai </li>
        </ol>
    </div>

    <button class="accordion" >KlikBCA Bisnis <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <b>Langkah-langkah transaksi BCA Virtual Account melalui KlikBCA Bisnis: </b>
        <br>
        <ul>
            <li>Daftar Transfer: <br>
                <ol>
                    <li>Pilih menu Daftar Transfer - Tambah, pilih Ke BCA Virtual Account</li>
                    <li>Masukkan nomor BCA Virtual Account</li>
                    <li>Ikuti langkah selanjutnya sampai selesai </li>
                </ol>
            </li>
            <li>Transfer Dana: <br>
                <ol>
                    <li>Pilih menu Transfer Dana – ke BCA Virtual Account</li>
                    <li>Pilih nomor rekening yang akan didebet dan pilih nomor BCA Virtual Account, lalu lanjut </li>
                    <li>Akan tampil konfirmasi transaksi: <br>
                        <ul>
                            <li>Masukkan jumlah nominal transfer dan berita, atau</li>
                            <li>Masukkan berita</li>
                        </ul>
                    </li>
                    <li>Ikuti langkah selanjutnya sampai transaksi selesai</li>
                </ol>
            </li>
            <li>Otorisasi Transaksi: <br>
                <ul style="list-style-type:none">
                    <li>Pilih menu Transfer Dana - Otorisasi Transaksi Tergantung single/multi otorisasi</li>
                    <li>Untuk Single Otorisasi: <br>
                        <ul>
                            Login User Releaser
                            <li>Tandai transaksi pada tabel Transaksi Yang Belum Diotorisasi, pilih Setuju </li>
                            <li>Ikuti langkah selanjutnya sampai selesai</li>
                        </ul>
                    </li>

                    <li>Untuk Multi Otorisasi: <br>
                        <ul>
                            <li>Login User Approver
                                <ol>
                                    <li>Tandai transaksi pada tabel Approver, pilih Setuju </li>
                                </ol>
                            </li>
                            <li>Login User Releaser
                                <ol>
                                    <li>Tandai transaksi pada tabel Transaksi Yang Belum Diotorisasi, pilih Setuju</li>
                                    <li>Ikuti langkah selanjutnya sampai selesai</li>
                                </ol>
                            </li>
                        </ul>
                    </li>
                </ul>
            </li>
        </ul>
    </div>

    <button class="accordion" >m-BCA (BCA Mobile) <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <b>Langkah-langkah transaksi BCA Virtual Account melalui m-BCA (BCA Mobile):</b>
        <br>
        <ol>
            <li>Pilih m-Transfer</li>
            <li>Pilih Transfer – BCA Virtual Account</li>
            <li>Pilih nomor rekening yang akan didebet</li>
            <li>Masukkan nomor BCA Virtual Account, lalu pilih OK</li>
            <li>Tampil konfirmasi nomor BCA Virtual Account dan rekening pendebetan, lalu Kirim</li>
            <li>Tampil konfirmasi pembayaran, lalu pilih OK <br>
                <ul>
                    <li>Masukkan jumlah nominal transfer dan berita, atau </li>
                    <li>Masukkan berita</li>
                </ul>
            </li>
            <li>Ikuti langkah selanjutnya sampai transaksi selesai </li>
        </ol>
    </div>

    <button class="accordion" >m-BCA (STK) <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <b>Langkah-langkah transaksi BCA Virtual Account melalui m-BCA (STK):</b>
        <br>
        <ol>
            <li>Pilih m-BCA </li>
            <li>Pilih m-Payment</li>
            <li>Pilih Lainnya</li>
            <li>Masukkan TVA pada Nama PT, lalu OK</li>
            <li>Masukkan nomor BCA Virtual Account pada No. Pelanggan, lalu OK</li>
            <li>Masukkan PIN m-BCA, lalu OK</li>
            <li>Pilih Pilih nomor rekening yang akan didebet, lalu lanjut</li>
            <li>Akan muncul konfirmasi pembayaran, lalu pilih OK <br>
                <ul>
                    <li>Masukkan jumlah bayar dan berita, atau </li>
                    <li>Masukkan berita</li>
                </ul>
            </li>
            <li>Ikuti langkah selanjutnya sampai transaksi selesai </li>
        </ol>
    </div>
    		<?php
    		break;
    	case '408':
    		?>
    <button class="accordion" style="display: block;">Pembayaran VA Melalui Mesin ATM Maybank - Menu Pembayaran <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <ol>
            <li>Pilih menu PEMBAYARAN/TOP UP PULSA</li>
            <li>Pilih menu VIRTUAL ACCOUNT</li>
            <li>Masukkan nomor VIRTUAL ACCOUNT yang tertera pada halaman konfirmasi</li>
            <li>Pilih YA untuk menyetujui pembayaran tersebut</li>
        </ol>
    </div>

    <button class="accordion" >Pembayaran VA Melalui Mesin ATM Maybank - Menu Transfer <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <ol>
            <li>Pilih menu TRANSFER</li>
            <li>Pilih menu VIRTUAL ACCOUNT</li>
            <li>Masukkan nomor VIRTUAL ACCOUNT yang tertera pada halaman konfirmasi</li>
            <li>Masukkan jumlah pembayaran sesuai dengan yang ditagihkan dalam halaman konfirmasi</li>
            <li>Silahkan masukkan nomor referensi apabila diperlukan, lalu tekan BENAR</li>
            <li>Pilih YA untuk menyetujui pembayaran tersebut</li>
        </ol>
    </div>

    <button class="accordion" >Pembayaran VA Melalui Maybank Internet Banking <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <ol>
            <li>Silahkan login Internet Banking dari Maybank</li>
            <li>Pilih menu Rekening dan Transaksi</li>
            <li>Kemudian pilih Maybank Virtual Account</li>
            <li>Masukkan nomor rekening dengan nomor Virtual Account Anda : <b><?php echo $trxid ?></b></li>
            <li>Masukkan jumlah pembayaran sesuai dengan yang ditagihkan dalam halaman konfirmasi</li>
            <li>Masukkan SMS Token (TAC) dan klik Setuju</li>
        </ol>
    </div>

    <button class="accordion" >Pembayaran VA Melalui ATM Bank lain <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <ol>
            <li>Pilih menu TRANSFER ANTAR BANK </li>
            <li>Pilih Maybank sebagai bank tujuan atau dengan memasukkan kode bank Maybank “016” diikuti dengan 16 digit nomor VIRTUAL ACCOUNT yang tertera pada halaman konfirmasi</li>
            <li>Masukkan jumlah pembayaran sesuai dengan yang ditagihkan dalam halaman konfirmasi</li>
            <li>Konfirmasikan transaksi anda pada halaman berikutnya. Apabila benar tekan BENAR untuk mengeksekusi transaksi</li>
        </ol>
    </div>
    		<?php
    		case '400':
    			?>
    			<button class="accordion" >Pembayaran Via Aplikasi <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel" style="display: block;">
      <p>
        <img src='<?php echo $srv."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/mocash.png" ; ?>' alt="How">
      </p>
    </div>

    <button class="accordion" >Pembayaran Via SMS <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <center>
            <p>
                Lakukan pembayaran dengan cara mengirim SMS ke 9123, ketik: BAYAR MD (spasi) STORE_ID
                (spasi) AMOUNT (spasi) ORDER_ID (spasi) PIN atau BAYAR MD 1902291 (spasi) 0 (spasi)
                <?php echo $trxid ?> (spasi) (PIN ANDA)
            </p>
        </center>
    </div>
    			<?php
    		break;
    		case '706':
    			?>
    			<button class="accordion" >Tata Cara Membayar Melalui Indomaret <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel" style="display: block;">
        <ol>
            <li>Catat dan simpan kode pembayaran Indomaret anda, yaitu : <b><?php echo $trxid?></b></li>
            <li>Tunjukan kode pembayaran ke kasir Indomaret terdekat dan lakukan pembayaran senilai <b><?php echo $currency." ".number_format($total).".00" ?></b></li>
            <li>Simpan bukti pembayaran yang sewaktu-waktu diperlukan jika terjadi kendala transaksi</li>
        </ol>
    </div>
    			<?php
    			break;
    		case '707':
    			?>
    			<button class="accordion menu-item-object-page" >Pembayaran Melalui Alfamart <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel" style="display: block;">
        <ol>
            <li>Catat dan simpan kode pembayaran Alfamart Anda, yaitu : <?php echo $trxid ?>.</li>
            <li>Datangi kasir Alfamart terdekat dan beritahukan pada kasir bahwa Anda ingin melakukan pembayaran "<?php echo $merchant ?>".</li>
            <li>Beritahukan kode pembayaran Alfamart Anda pada kasir dan silahkan lakukan pembayaran Anda senilai <?php echo $currency." ".number_format($total).".00" ?>.</li>
            <li>Simpan struk pembayaran Anda sebagai tanda bukti pembayaran yang sah.</li>
        </ol>
    </div>
    			<?php
    			break;
    	case '703':
    		?>
    <button class="accordion" style="display: block;">Tata Cara Membayar Melalui ATM <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <ol>
            <li>Catat kode pembayaran yang anda dapat</li>
            <li>Gunakan ATM Mandiri untuk menyelesaikan pembayaran</li>
            <li>Masukkan PIN anda</li>
            <li>Pilih 'Bayar/Beli' lalu pilih 'Lainnya'</li>
            <li>Cari pilihan MULTI PAYMENT</li>
            <li>Masukkan Kode Perusahaan <b><?php echo $mid ?></b></li>
            <li>Masukkan Kode Pelanggan <b><?php echo $trxid ?></b></li>
            <li>Pilih Tagihan Anda jika sudah sesuai tekan YA</li>
            <li>Konfirmasikan tagihan anda apakah sudah sesuai lalu tekan YA</li>
            <li>Harap Simpan Struk Transaksi yang anda dapatkan</li>
        </ol>
    </div>

    <button class="accordion" >Tata Cara Membayar Melalui Mandiri Internet Banking <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <ol>
            <li>Pada Halaman Utama pilih submenu Lain-lain di bawah menu Pembayaran</li>
            <li>Cari Penyedia Jasa 70009 MitraPay</li>
            <li>Isi Nomor Pelanggan yang anda dapatkan</li>
            <li>Masukkan Jumlah Pembayaran sesuai dengan Jumlah Tagihan anda</li>
            <li>Pilih LANJUTKAN</li>
            <li>Transaksi selesai, jika perlu CETAK hasil transaksi anda</li>
        </ol>
    </div>
    		<?php
    		break;
        case '711':
            ?>
                <button class="accordion" style="display: block;">Pembayaran melalui ShopeePay <i class="fa fa-arrow-down" style="float: right;"></i></button>
                <div class="panel">
                    <ol>
                        <li>Buka aplikasi Shopee</li>
                        <li>Klik logo “Scan”</li>
                        <li>Scan QR Code</li>
                        <li>Klik tombol “Bayar Sekarang”</li>
                    </ol>
                </div>

                <button class="accordion" >Pembayaran melalui Mobile Banking atau E-Money lainnya <i class="fa fa-arrow-down" style="float: right;"></i></button>
                <div class="panel">
                    <ol>
                        <li>Buka aplikasi mobile banking atau e-money</li>
                        <li>Klik logo “Pay” atau “Scan”</li>
                        <li>Scan QR Code</li>
                        <li>Klik tombol “Pay” atau “Bayar”</li>
                    </ol>
                </div>
            <?php
            break;
    	default:
    		# code...
    		break;
    }
}
 ?>
=======
<?php 
require_once '../../../wp-config.php';
require_once '../../../wp-settings.php';
global $woocommerce;
function get_pict($ch){
    $url = get_site_url();
    switch ($ch) {
        case '800':
        echo $url."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/bri.png";
        break;
        case '801':
        echo $url."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/bni.png";
        break;
        case '802':
        echo $url."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/mandiricp.png";
        break;
        case '707':
        echo $url."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/alfamart.png";
        break;
        case '708':
        echo $url."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/danamononline.png";
        break;
        case '701':
        echo $url."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/danamononline.png";
        break;
        case '706':
        echo $url."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/indomaret.png";
        break;
        case '703':
        echo $url."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/mandiricp.png";
        break;
        case '702':
        echo $url."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/bca.png";
        break;
        case '405':
        echo $url."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/bca-klikpay.png";
        break;
        case '408':
        echo $url."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/maybank.png";
        break;
        case '407':
        echo $url."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/maybank.png";
        break;
        case '402':
        echo $url."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/va_permata.png";
        break;
        case '400':
        echo $url."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/mocash.png";
        break;
        case '303':
        echo $url."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/xl_tunai.png";
        break;
        case '711':
        echo $url."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/shoppepayQRIS.png";
        break;
        case '713':
        echo $url."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/shoppepayApp.png";
        break;
        case '818':
        echo $url."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/sinarmas.png";
        break;
        case '825':
        echo $url."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/cimbniaga.png";
        break;
        default:
        echo $url."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/faspay-logo.jpg";
        break;
    }
}
function get_name($ch){
    switch ($ch) {
        case '800':
        return "BRI Virtual Account";
        break;
        case '801':
        return "BNI Virtual Account";
        break;
        case '802':
        return "Mandiri Virtual Account";
        break;
        case '707':
        return "Alfamart";
        break;
        case '708':
        return "Danamon Virtual Account";
        break;
        case '701':
        return "Danamon Virtual Account";
        break;
        case '706':
        return "Indomaret";
        break;
        case '703':
        return "Mandiri Virtual Account";
        break;
        case '702':
        return "BCA Virtual Account";
        break;
        case '405':
        return "BCA - KlikPay";
        break;
        case '408':
        return "Maybank";
        break;
        case '407':
        return "Maybank";
        break;
        case '402':
        return "Permata Virtual Account";
        break;
        case '400':
        return "Mocash";
        break;
        case '303':
        return "XL Tunai";
        break;
        case '711':
        return "shoppepayQRIS";
        break;
        case '713':
        return "Shoppepay";
        break;
        case '818':
        return "Sinarmas Virtual Account";
        break;
        case '825':
        return "CIMB Niaga Virtual Account";
        break;
        default:
        return "Faspay";
        break;
    }
}
function get_guide($ch,$trxid,$merchant,$mid,$currency,$total){
    switch ($ch) {
        case '800':
        ?>
        <button class="accordion">Tata Cara Membayar Melalui ATM BRI<i class="fa fa-arrow-down" style="float: right;"></i></button>
        <div class="panel" style="display: block;">
            <ol>
                <li>Nasabah melakukan pembayaran melalui ATM Bank BRI</li>
                <li>Pilih Menu Transaksi Lain</li>
                <li>Pilih Menu Pembayaran</li>
                <li>Pilih Menu Lainnya</li>
                <li>Pilih Menu BRIVA</li>
                <li>Masukan 16 digit Nomor Virtual Account :<?php echo $trxid ?>.</li>
                <li>Proses Pembayaran (Ya/Tidak)</li>
                <li>Harap Simpan Struk Transaksi yang anda dapatkan</li>
            </ol>
        </div>
        <button class="accordion" >Tata Cara Membayar Melalui Mobile Banking BRI <i class="fa fa-arrow-down" style="float: right;"></i></button>
        <div class="panel">
            <li>Nasabah melakukan pembayaran melalui Mobile/SMS Banking BRI</li>
            <li>Nasabah memilih Menu Pembayaran melalui Menu Mobile/SMS Banking BRI</li>
            <li>Nasabah memilih Menu BRIVA</li>
            <li>Masukan 16 digit Nomor Virtual Account : <?php echo $trxid ?></li>
            <li>Masukan Jumlah Pembayaran sesuai Tagihan</li>
            <li>Masukan PIN Mobile/SMS Banking BRI</li>
            <li>Nasabah mendapat Notifikasi Pembayaran</li>
        </div>
        <button class="accordion" >Tata Cara Membayar Melalui Internet Banking BRI <i class="fa fa-arrow-down" style="float: right;"></i></button>
        <div class="panel">
            <li>Nasabah melakukan pembayaran melalui Internet Banking BRI</li>
            <li>Nasabah memilih Menu Pembayaran</li>
            <li>Nasabah memilih Menu BRIVA</li>
            <li>Masukan Kode Bayar dengan 16 digit Nomor Virtual Account : <?php echo $trxid ?>.</li>
            <li>Masukan Password Internet Banking BRI</li>
            <li>Masukan mToken Internet Banking BRI</li>
            <li>Nasabah mendapat Notifikasi Pembayaran</li>
        </div>
        <button class="accordion" >Tata Cara Membayar Melalui ATM Bank Lain <i class="fa fa-arrow-down" style="float: right;"></i></button>
        <div class="panel">
            <li>Nasabah melakukan pembayaran melalui ATM Bank Lain yang dimiliki Nasabah melalui Menu Transfer Antar Bank</li>
            <li>Masukan Kode Bank Tujuan : BRI (Kode Bank : 002) + Nomor Virtual Account : <?php echo $trxid ?>.</li>
            <li>Masukan Jumlah Pembayaran sesuai Tagihan</li>
            <li>Proses Pembayaran (Ya/Tidak)</li>
            <li>Masukan Password Internet Banking BRI</li>
            <li>Masukan mToken Internet Banking BRI</li>
            <li>Harap Simpan Struk Transaksi yang anda dapatkan</li>
        </div>
        <?php
        break;
        case '303':
        ?>
        <button class="accordion">Tata Cara Membayar <i class="fa fa-arrow-down" style="float: right;"></i></button>
        <div class="panel" style="display: block;">
            <ol>
                <li>Ketik *123*120# dari handphone Anda, lalu tekan OK/YES</li>
                <li>Setelah muncul menu transaksi XL Tunai, ketik 4 (pilihan Belanja Online)</li>
                <li>Ketik 1 (Lanjut) lalu Kirim</li>
                <li>Masukkan kode merchant <?php echo $merchant ?> <b><u><?php echo $mid ?></u></b> lalu Kirim</li>
                <li>Masukkan Nomor Pesanan sesuai dengan yang tertera pada laman TERIMA KASIH, lalu Kirim.</li>
                <li>Jika pembayaran berhasil, Anda akan menerima notifikasi pembayaran berhasil melalui SMS.</b></li>
            </ol>
        </div>
        <?php
        break;
        case '802':
        ?> 
        <button class="accordion">Tata Cara Membayar Melalui ATM</button>
        <div class="panel" style="display: block;">
            <ol>
               <li>Catat kode pembayaran yang anda dapat</li>
               <li>Gunakan ATM Mandiri untuk menyelesaikan pembayaran</li>
               <li>Masukkan PIN anda</li>
               <li>Pilih 'Bayar/Beli'</li>
               <li>Cari pilihan MULTI PAYMENT</li>
               <li>Masukkan Kode Perusahaan <b>88308</b></li>
               <li>Masukkan Kode Pelanggan <b><?php echo $trxid ?></b></li>
               <li>Masukkan Jumlah Pembayaran sesuai dengan Jumlah Tagihan anda kemudian tekan 'Benar'</li>
               <li>Pilih Tagihan Anda jika sudah sesuai tekan YA</li>
               <li>Konfirmasikan tagihan anda apakah sudah sesuai lalu tekan YA</li>
               <li>Harap Simpan Struk Transaksi yang anda dapatkan</li>
           </ol>
       </div>
       <button class="accordion" >Tata Cara Membayar Melalui Internet Banking Mandiri <i class="fa fa-arrow-down" style="float: right;"></i></button>
       <div class="panel">
        <li>Pada Halaman Utama pilih menu BAYAR</li>
        <li>Pilih submenu MULTI PAYMENT</li>
        <li>Cari Penyedia Jasa 'FASPAY'</li>
        <li>Masukkan Kode Pelanggan <b><?php echo $trxid ?></b></li>
        <li>Masukkan Jumlah Pembayaran sesuai dengan Jumlah Tagihan anda</li>
        <li>Pilih LANJUTKAN</li>
        <li>Pilih Tagihan Anda jika sudah sesuai tekan LANJUTKAN</li>
        <li>Transaksi selesai, jika perlu CETAK hasil transaksi anda</li>
    </div>
    <button class="accordion" >Pembayaran melalui ATM Prima <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <ol>
            <li>Masukkan PIN</li>
            <li>Pilih menu TRANSAKSI LAINNYA</li>
            <li>Pilih menu KE REK BANK LAIN</li>
            <li>Masukkan kode sandi Bank Mandiri (008) kemudian tekan BENAR</li>
            <li>Masukkan nomor VIRTUAL ACCOUNT yang tertera pada halaman konfirmasi, dan tekan BENAR</li>
            <li>Masukkan jumlah pembayaran sesuai dengan yang ditagihkan dalam halaman konfirmasi</li>
            <li>Pilih BENAR untuk menyetujui transaksi tersebut</li>
        </ol>
    </div>
    <button class="accordion" >Pembayaran melalui ATM Bersama <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <ol>
            <li>Masukkan PIN</li>
            <li>Pilih menu TRANSAKSI</li>
            <li>Pilih menu KE REK BANK LAIN</li>
            <li>Masukkan kode sandi Bank Mandiri (008) diikuti dengan nomor VIRTUAL ACCOUNT yang tertera pada halaman konfirmasi, dan tekan BENAR</li>
            <li>Masukkan jumlah pembayaran sesuai dengan yang ditagihkan dalam halaman konfirmasi</li>
            <li>Pilih BENAR untuk menyetujui transaksi tersebut</li>
        </ol>
    </div>
    <button class="accordion" >Pembayaran Mandiri Virtual Account dengan Mandiri Online <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <ol>
            <li>Login Mandiri Online dengan memasukkan username dan password</li>
            <li>Pilih menu PEMBAYARAN</li>
            <li>Pilih menu MULTI PAYMENT </li>
            <li>Cari Penyedia Jasa 'FASPAY'</li>
            <li>Masukkan Nomor Virtual Account <b><?php echo $trxid ?></b> dan nominal yang akan dibayarkan, lalu pilih Lanjut</li>
            <li>Setelah muncul tagihan, pilih Konfirmasi</li>
            <li>Masukkan PIN/ challange code token</li>
            <li>Transaksi selesai, simpan bukti bayar anda</li>
        </ol>
    </div>
    <?php
    break;
    case '818': ?>
    <button class="accordion" >Pembayaran Melalui Menu Transfer Mesin ATM <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <ol>
            <small>
                <li>Pilih “Transfer” </li>
                <li> Pilih “Rekening Bank Sinarmas” </li>
                <li> Pilih “Rekening Nasabah Lain” </li>
                <li> Masukkan kode Virtual Account + No. Pelanggan Contoh : 8856996104265376</li>
                <li> Tagihan akan muncul secara otomatis atau masukkan jumlah nominal yang akan dibayarkan </li>
                <li> Pastikan nama penerima dan jumlah sesuai dengan yang akan dibayarkan</li>
                <li>Jika informasi sudah benar, pilih BENAR</li>
            </ol>
        </small>
    </div>
    <button class="accordion" >Pembayaran Melalui Menu Transfer pada Internet Banking <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <ol>
            <small>
                <li> Pilih “Transfer Dana” </li>
                <li> Pilih “Transfer Bank Sinarmas” </li>
                <li> Masukkan kode Virtual Account + No. Pelanggan Contoh : 8856996104265376 </li>
                <li> Tagihan akan muncul secara otomatis atau masukkan jumlah nominal yang akan dibayarkan </li>
                <li> Pastikan nama penerima dan jumlah sesuai dengan yang akan dibayarkan </li>
                <li> Silahkan masukkan Nomor Token atau SMS Token Anda</li>
            </small>
        </ol>
    </div>
    <button class="accordion" >Pembayaran Melalui Mesin ATM Bank Lain (ATM Bersama, ALTO, Prima) <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <ol>
            <small>
                <li> Masuk ke menu “Layanan Transfer” </li>
                <li>Lalu pilih “Transfer Rek. Bank Lain” </li>
                <li>Masukkan kode sandi Bank Sinarmas (153) terlebih dahulu Masukkan 153 + 8MMM + No. Pelanggan Contoh : 8856996104265376</li>
                <li>Tagihan akan muncul secara otomatis atau masukkan jumlah nominal yang akan dibayarkan </li>
                <li>Pastikan nama penerima dan jumlah sesuai dengan yang akan dibayarkan</li>
            </small>
        </ol>
    </div>
    <button class="accordion" >Cara Pembayaran Melalui Menu Pembayaran pada Mesin ATM <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <ol>
            <small>
                <li>Pilih “Pembayaran” </li>
                <li> Pilih “Layar Berikutnya” </li>
                <li> Pilih “Virtual Account” </li>
                <li> Masukkan kode Virtual Account + No. Pelanggan Contoh : 8856996104265376 </li>
                <li> Tagihan akan muncul secara otomatis atau masukkan jumlah nominal yang akan dibayarkan </li>
                <li> Pastikan nama penerima dan jumlah sesuai dengan yang akan dibayarkan</li>
            </small>
        </ol>
    </div>
    <button class="accordion" >Cara Pembayaran Melalui Menu Pembayaran pada Internet Banking <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <ol>
            <small>
                <li>Pilih “Pembayaran/Pembelian” </li>
                <li> Pilih “Virtual Account” </li>
                <li> Masukkan kode Virtual Account + No. Pelanggan pada kolom IPDEL Contoh : 8856996104265376 </li>
                <li> Tagihan akan muncul secara otomatis </li>
                <li> Pastikan nama penerima dan jumlah sesuai dengan yang akan dibayarkan</li>
            </small>
        </ol>
    </div>
    <?php
    break;
    case '825': ?>
    <button class="accordion" >Pembayaran VA melalui ATM CIMB NIAGA <i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <ol>
            <small>
                <li>Masukan kartu ATM dan PIN CIMB Niaga Anda</li>
                <li>Pilih Menu Pembayaran</li>
                <li>Pilih Virtual Account</li>
                <li>Masukkan NOMOR VIRTUAL ACCOUNT</li>
                <li>Muncul nama dan nominal billing di layar konfirmasi</li>
                <li>Pilih OK untuk payment</li>
            </small>
        </ol>
    </div>
    <button class="accordion" >Pembayaran VA melalui ATM BERSAMA/PRIMA/BANK LAIN<i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <ol>
            <small>
                <li>Masukan kartu ATM dan PIN Anda</li>
                <li>Masuk ke menu TRANSFER/TRANSFER Online</li>
                <li>Pilih Bank tujuan -&gt; Bank CIMB Niaga (kode bank: 022)</li>
                <li>Masukkan nomor Virtual Account Anda</li>
                <li>Masukkan jumlah pembayaran sesuai tagihan</li>
                <li>Ikuti instruksi untuk menyelesaikan transaksi</li>
            </small>
        </ol>
    </div>
    <button class="accordion" >Pembayaran VA melalui OCTO Clicks<i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <ol>
            <small>
                <li>Login ke OCTO Clicks</li>
                <li>Pilih menu Pembayaran Tagihan</li>
                <li>Pilih kategori Mobile Rekening Virtual</li>
                <li>Masukkan nomor Virtual Account Anda</li>
                <li>Tekan tombol 'lanjut untuk verifikasi detail'</li>
                <li>Tekan tombol 'kirim OTP untuk lanjut'</li>
                <li>Masukkan OTP yang dikirimkan ke nomor HP anda</li>
                <li>Tekan tombol 'Konfirmasi'</li>
            </small>
        </ol>
    </div>
    <button class="accordion" >Pembayaran VA melalui Internet Banking Bank Lain<i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <ol>
            <small>
                <li>Login Ke Internet Banking</li>
                <li>Pilih menu Transfer ke Bank Lain Online</li>
                <li>Pilih bank tujuan Bank CIMB Niaga (kode bank: 022)</li>
                <li>Masukkan nomor Virtual Account Anda</li>
                <li>Masukan jumlah amount sesuai tagihan</li>
                <li>Ikuti instruksi untuk menyelesaikan transaksi</li>
            </small>
        </ol>
    </div>
    <button class="accordion" >Pembayaran VA melalui OCTO MOBILE<i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <ol>
            <small>
                <li>Login ke Octo Mobile</li>
                <li>Pilih menu TRANSFER &gt; Transfer to Other CIMB Niaga Account</li>
                <li>Pilih rekening sumber anda: CASA atau Rekening Ponsel</li>
                <li>Masukkan nomor Virtual Account Anda pada kolom Transfer To</li>
                <li>Masukkan jumlah amount sesuai tagihan</li>
                <li>Ikuti instruksi untuk menyelesaikan transaksi</li>
            </small>
        </ol>
    </div>
    <button class="accordion" >Pembayaran VA melalui EDC<i class="fa fa-arrow-down" style="float: right;"></i></button>
    <div class="panel">
        <ol>
            <small>
                <li>Pada menu EDC pilih menu ‘Virtual Account’ menggunakan kursor</li>
                <li>Pilih ‘Pembayaran Tagihan VA’ dengan menggunakan tombol kursor</li>
                <li>Kemudian masukkan / gesekkan kartu CIMB Niaga</li>
                <li>Konfirmasi kartu jika ingin melanjutkan, Pilih YES atau tekan tombol ENTER</li>
                <li>Masukkan nomor virtual account</li>
                <li>Kemudian pilih jenis Rekening anda dengan menggunakan tombol angka 1 atau 2, lalu tekan ENTER</li>
                <li>Ikuti instruksi untuk menyelesaikan transaksi</li>
            </small>
        </ol>
    </div>
</div>
<?php
break;
case '402':
?>
<button class="accordion" >Pembayaran Melalui ATM Permata <i class="fa fa-arrow-down" style="float: right;"></i></button>
<div class="panel" style="display: block;">
    <ol>
        <li>Masukkan PIN</li>
        <li>Pilih menu TRANSAKSI LAINNYA</li>
        <li>Pilih menu PEMBAYARAN</li>
        <li>Pilih menu PEMBAYARAN LAINNYA</li>
        <li>Pilih menu VIRTUAL ACCOUNT</li>
        <li>Masukkan nomor VIRTUAL ACCOUNT yang tertera pada halaman konfirmasi, dan tekan BENAR</li>
        <li>Pilih rekening yang menjadi sumber dana yang akan didebet, lalu tekan YA untuk konfirmasi transaksi</li>
    </ol>
</div>
<button class="accordion" >Pembayaran melalui ATM Prima <i class="fa fa-arrow-down" style="float: right;"></i></button>
<div class="panel">
    <ol>
        <li>Masukkan PIN</li>
        <li>Pilih menu TRANSAKSI LAINNYA</li>
        <li>Pilih menu KE REK BANK LAIN</li>
        <li>Masukkan kode sandi Bank Permata (013) kemudian tekan BENAR</li>
        <li>Masukkan nomor VIRTUAL ACCOUNT yang tertera pada halaman konfirmasi, dan tekan BENAR</li>
        <li>Masukkan jumlah pembayaran sesuai dengan yang ditagihkan dalam halaman konfirmasi</li>
        <li>Pilih BENAR untuk menyetujui transaksi tersebut</li>
    </ol>
</div>
<button class="accordion" >Pembayaran melalui ATM Bersama <i class="fa fa-arrow-down" style="float: right;"></i></button>
<div class="panel">
    <ol>
        <li>Masukkan PIN</li>
        <li>Pilih menu TRANSAKSI</li>
        <li>Pilih menu KE REK BANK LAIN</li>
        <li>Masukkan kode sandi Bank Permata (013) diikuti dengan nomor VIRTUAL ACCOUNT yang tertera pada halaman konfirmasi, dan tekan BENAR</li>
        <li>Masukkan jumlah pembayaran sesuai dengan yang ditagihkan dalam halaman konfirmasi</li>
        <li>Pilih BENAR untuk menyetujui transaksi tersebut</li>
    </ol>
</div>
<button class="accordion" >Pembayaran Melalui Permata Mobile <i class="fa fa-arrow-down" style="float: right;"></i></button>
<div class="panel">
    <ol>
        <li>Buka aplikasi PermataMobile Internet (Android/iPhone)</li>
        <li>Masukkan User ID & Password</li>
        <li>Pilih Pembayaran Tagihan</li>
        <li>Pilih Virtual Account</li>
        <li>Masukkan 16 digit nomor Virtual Account yang tertera pada halaman konfirmasi</li>
        <li>Masukkan nominal pembayaran sesuai dengan yang ditagihkan</li>
        <li>Muncul Konfirmasi pembayarann</li>
        <li>Masukkan otentikasi transaksi/token</li>
        <li>Transaksi selesai</li>
    </ol>
</div>
<button class="accordion" >Pembayaran Melalui Permata Net <i class="fa fa-arrow-down" style="float: right;"></i></button>
<div class="panel">
    <ol>
        <li>Buka website PermataNet: <a href="https://new.permatanet.com">https://new.permatanet.com</a></li>
        <li>Masukkan User ID & Password</li>
        <li>Pilih Pembayaran Tagihan</li>
        <li>Pilih Virtual Account</li>
        <li>Masukkan 16 digit nomor Virtual Account yang tertera pada halaman konfirmasi</li>
        <li>Masukkan nominal pembayaran sesuai dengan yang ditagihkan</li>
        <li>Muncul Konfirmasi pembayarann</li>
        <li>Masukkan otentikasi transaksi/token</li>
        <li>Transaksi selesai</li>
    </ol>
</div>
<?php
break;
case '801':
?>
<button class="accordion" >Tata Cara Membayar Melalui ATM BNI <i class="fa fa-arrow-down" style="float: right;"></i></button>
<div class="panel" style="display: block;">
    <ol>
        <li>Nasabah melakukan pembayaran melalui ATM Bank BNI</li>
        <li>Pilih Menu Lainnya</li>
        <li>Pilih Menu Transfer</li>
        <li>Pilih Menu Rekening Tabungan</li>
        <li>Pilih Menu Ke Rekening BNI</li>
        <li>Masukan 16 digit Nomor Virtual Account <b><?php echo $trxid ?></b></li>
        <li>Masukan Nominal Transfer</li>
        <li>Konfirmasi Pemindahbukuan</li>
        <li>Transaksi Selesai. Harap Simpan Struk Transaksi yang anda dapatkan</li>
    </ol>
</div>
<button class="accordion" >Tata Cara Membayar Melalui SMS Banking BNI <i class="fa fa-arrow-down" style="float: right;"></i></button>
<div class="panel">
    <ol>
        <li>Nasabah melakukan pembayaran melalui SMS Banking BNI</li>
        <li>Pilih Menu Transfer</li>
        <li>Masukan 16 digit Nomor Virtual Account <b><?php echo $trxid ?></b></li>
        <li>Masukan Jumlah Pembayaran. Kemudian Proses</li>
        <li>Akan Muncul Popup dan kemudian Pilih Yes lalu Send</li>
        <li>Anda akan mendapatkan SMS konfirmasi dari BNI</li>
        <li>Reply SMS dengan ketik pin digit ke 2 & 3</li>
        <li>Transaksi Berhasil</li>
    </ol>
    <br>
    Atau bisa juga langsung mengetik sms dan kirim ke 3346 dengan format
    <br>
    <ol>
        <li><b>TRF[SPASI]NOMOR VA BNI[SPASI]NOMINAL</b></li>
        <li>Anda akan mendapatkan SMS konfirmasi dari BNI</li>
        <li>Reply SMS dengan ketik pin digit ke 2 & 3</li>
        <li>Transaksi Berhasil</li>
    </ol>
</div>
<button class="accordion" >Internet Banking BNI <i class="fa fa-arrow-down" style="float: right;"></i></button>
<div class="panel">
    <ol>
        <li>Nasabah melakukan pembayaran melalui Internet Banking BNI</li>
        <li>Ketik alamat <a href="https://ibank.bni.co.id">https://ibank.bni.co.id</a></li>
        <li>Masukkan User ID dan Password</li>
        <li>Klik menu <b>TRANSFER</b> kemudian pilih <b>TAMBAH REKENING FAVORIT</b>. Jika menggunakan Desktop/PC untuk menambah rekening pada menu <b>Transaksi</b> kemudian <b>Atur Rekening Tujuan</b> lalu <b>Tambah Rekening Tujuan</b></li>
        <li>Masukan Nama dan Kode Bayar dengan 16 digit Nomor Virtual Account <b><?php echo $trxid ?></b></li>
        <li>Masukan Kode Otentikasi Token</li>
        <li>Nomor Rekening Tujuan Berhasil Ditambahkan</li>
        <li>Kembali ke menu TRANSFER. Pilih TRANSFER ANTAR REKENING BNI, kemudian pilih rekening tujuan</li>
        <li>Pilih Rekening Debit dan ketik nominal, lalu masukkan kode otentikasi token</li>
        <li>Transfer Anda Telah Berhasil</li>
    </ol>
</div>
<button class="accordion" >Mobile Banking BNI <i class="fa fa-arrow-down" style="float: right;"></i></button>
<div class="panel">
    <ol>
        <li>Akses BNI Mobile Banking dari handphone kemudian masukkan User ID dan Password</li>
        <li>Pilih menu Transfer</li>
        <li>Pilih Antar Rekening BNI kemudian Input Rekening Baru</li>
        <li>Masukkan nomor Rekening Debit</li>
        <li>Masukkan nomor Rekening Tujuan dengan 16 digit Nomor Virtual Account <b><?php echo $trxid ?></b></li>
        <li>Masukkan jumlah pembayaran. Klik Benar</li>
        <li>Konfirmasi transaksi dan masukkan Password Transaksi</li>
        <li>Transaksi Anda Telah Berhasil</li>
    </ol>
</div>
<button class="accordion" >ATM Bank Lain <i class="fa fa-arrow-down" style="float: right;"></i></button>
<div class="panel">
    <ol>
        <li>Nasabah melakukan pembayaran melalui ATM Bank Lain</li>
        <li>Pilih menu Transaksi Lainnya</li>
        <li>Pilih menu Transfer</li>
        <li>Pilih Rekening BNI Lain</li>
        <li>Masukkan Kode Bank BNI (009) dan Pilih Benar</li>
        <li>Masukkan jumlah pembayaran</li>
        <li>Masukkan 16 digit Nomor Virtual Account <b><?php echo $trxid ?></b></li>
        <li>Pilih Rekening yang akan di debit</li>
        <li>Konfirmasi Pembayaran</li>
        <li>Transaksi Selesai. Harap Simpan Struk Transaksi yang anda dapatkan</li>
    </ol>
</div>
<?php
break;
case '708':
?>
<button class="accordion" >Pembayaran Melalui ATM Danamon <i class="fa fa-arrow-down" style="float: right;"></i></button>
<div class="panel" style="display: block;">
    <b>Pembayaran Melalui ATM Danamon</b>
    <ol>
        <li>Masuk ke menu Pembayaran -> Lainnya -> Virtual Account </li>
        <li>Masukkan 16 digit nomor Virtual Account </li>
        <li>Periksa jumlah tagihan dan konfirmasi pembayaran. </li>
    </ol>
</div>
<button class="accordion" >Transfer dari Bank Lain <i class="fa fa-arrow-down" style="float: right;"></i></button>
<div class="panel">
    <ol>
        <li>Transfer melalui Bank Lain yang tergabung dalam jaringan ATM Bersama, ALTO dan Prima.</li>
        <li>Masukkan kode Bank Danamon (011) dan 16 digit nomor Virtual Account di rekening tujuan.</li>
        <li>Masukkan nominal transfer sesuai tagihan.</li>
    </ol>
</div>
<?php
break;
case '702':
?>
<button class="accordion" style="display: block;">Tata Cara Membayar Melalui ATM/ANT/SETAR-Setor Tarik <i class="fa fa-arrow-down" style="float: right;"></i></button>
<div class="panel">
    <b>Langkah-langkah transaksi BCA Virtual Account melalui ATM/ANT/SETAR-Setor Tarik:</b>
    <br>
    <ol>
        <li>Pilih menu Transfer – Ke Rek BCA Virtual Account</li>
        <li>Masukkan Nomor BCA Virtual Account, lalu pilih Benar</li>
        <li>Pilih menu “Ke Rek BCA Virtual Account”</li>
        <li>Layar ATM akan menampilkan konfirmasi transaksi:<br>
            <ul>
                <li>Pilih Ya bila setuju, atau </li>
                <li>Masukkan jumlah transfer, lalu pilih Benar. Layar ATM akan kembali menampilkan konfirmasi jumlah pembayaran, pilih Ya bila ingin membayar</li>
            </ul>
        </li>
        <li>Ikuti langkah selanjutnya sampai transaksi selesai</li>
    </ol>
</div>
<button class="accordion" >KlikBCA Individu (Full Site dan versi Smartphone) <i class="fa fa-arrow-down" style="float: right;"></i></button>
<div class="panel">
    <b>Langkah-langkah transaksi BCA Virtual Account melalui KlikBCA Individu: </b>
    <br>
    <ol>
        <li>Pilih Menu Transfer Dana – Transfer ke BCA Virtual Account</li>
        <li>Masukkan nomor BCA Virtual Account, atau pilih Dari Daftar Transfer </li>
        <li>Akan tampil konfirmasi transaksi: <br>
            <ul>
                <li>Masukkan jumlah nominal transfer dan berita, atau </li>
                <li>Masukkan berita</li>
            </ul>
        </li>
        <li>Ikuti langkah selanjutnya sampai transaksi selesai </li>
    </ol>
</div>
<button class="accordion" >KlikBCA Bisnis <i class="fa fa-arrow-down" style="float: right;"></i></button>
<div class="panel">
    <b>Langkah-langkah transaksi BCA Virtual Account melalui KlikBCA Bisnis: </b>
    <br>
    <ul>
        <li>Daftar Transfer: <br>
            <ol>
                <li>Pilih menu Daftar Transfer - Tambah, pilih Ke BCA Virtual Account</li>
                <li>Masukkan nomor BCA Virtual Account</li>
                <li>Ikuti langkah selanjutnya sampai selesai </li>
            </ol>
        </li>
        <li>Transfer Dana: <br>
            <ol>
                <li>Pilih menu Transfer Dana – ke BCA Virtual Account</li>
                <li>Pilih nomor rekening yang akan didebet dan pilih nomor BCA Virtual Account, lalu lanjut </li>
                <li>Akan tampil konfirmasi transaksi: <br>
                    <ul>
                        <li>Masukkan jumlah nominal transfer dan berita, atau</li>
                        <li>Masukkan berita</li>
                    </ul>
                </li>
                <li>Ikuti langkah selanjutnya sampai transaksi selesai</li>
            </ol>
        </li>
        <li>Otorisasi Transaksi: <br>
            <ul style="list-style-type:none">
                <li>Pilih menu Transfer Dana - Otorisasi Transaksi Tergantung single/multi otorisasi</li>
                <li>Untuk Single Otorisasi: <br>
                    <ul>
                        Login User Releaser
                        <li>Tandai transaksi pada tabel Transaksi Yang Belum Diotorisasi, pilih Setuju </li>
                        <li>Ikuti langkah selanjutnya sampai selesai</li>
                    </ul>
                </li>
                <li>Untuk Multi Otorisasi: <br>
                    <ul>
                        <li>Login User Approver
                            <ol>
                                <li>Tandai transaksi pada tabel Approver, pilih Setuju </li>
                            </ol>
                        </li>
                        <li>Login User Releaser
                            <ol>
                                <li>Tandai transaksi pada tabel Transaksi Yang Belum Diotorisasi, pilih Setuju</li>
                                <li>Ikuti langkah selanjutnya sampai selesai</li>
                            </ol>
                        </li>
                    </ul>
                </li>
            </ul>
        </li>
    </ul>
</div>
<button class="accordion" >m-BCA (BCA Mobile) <i class="fa fa-arrow-down" style="float: right;"></i></button>
<div class="panel">
    <b>Langkah-langkah transaksi BCA Virtual Account melalui m-BCA (BCA Mobile):</b>
    <br>
    <ol>
        <li>Pilih m-Transfer</li>
        <li>Pilih Transfer – BCA Virtual Account</li>
        <li>Pilih nomor rekening yang akan didebet</li>
        <li>Masukkan nomor BCA Virtual Account, lalu pilih OK</li>
        <li>Tampil konfirmasi nomor BCA Virtual Account dan rekening pendebetan, lalu Kirim</li>
        <li>Tampil konfirmasi pembayaran, lalu pilih OK <br>
            <ul>
                <li>Masukkan jumlah nominal transfer dan berita, atau </li>
                <li>Masukkan berita</li>
            </ul>
        </li>
        <li>Ikuti langkah selanjutnya sampai transaksi selesai </li>
    </ol>
</div>
<button class="accordion" >m-BCA (STK) <i class="fa fa-arrow-down" style="float: right;"></i></button>
<div class="panel">
    <b>Langkah-langkah transaksi BCA Virtual Account melalui m-BCA (STK):</b>
    <br>
    <ol>
        <li>Pilih m-BCA </li>
        <li>Pilih m-Payment</li>
        <li>Pilih Lainnya</li>
        <li>Masukkan TVA pada Nama PT, lalu OK</li>
        <li>Masukkan nomor BCA Virtual Account pada No. Pelanggan, lalu OK</li>
        <li>Masukkan PIN m-BCA, lalu OK</li>
        <li>Pilih Pilih nomor rekening yang akan didebet, lalu lanjut</li>
        <li>Akan muncul konfirmasi pembayaran, lalu pilih OK <br>
            <ul>
                <li>Masukkan jumlah bayar dan berita, atau </li>
                <li>Masukkan berita</li>
            </ul>
        </li>
        <li>Ikuti langkah selanjutnya sampai transaksi selesai </li>
    </ol>
</div>
<?php
break;
case '408':
?>
<button class="accordion" style="display: block;">Pembayaran VA Melalui Mesin ATM Maybank - Menu Pembayaran <i class="fa fa-arrow-down" style="float: right;"></i></button>
<div class="panel">
    <ol>
        <li>Pilih menu PEMBAYARAN/TOP UP PULSA</li>
        <li>Pilih menu VIRTUAL ACCOUNT</li>
        <li>Masukkan nomor VIRTUAL ACCOUNT yang tertera pada halaman konfirmasi</li>
        <li>Pilih YA untuk menyetujui pembayaran tersebut</li>
    </ol>
</div>
<button class="accordion" >Pembayaran VA Melalui Mesin ATM Maybank - Menu Transfer <i class="fa fa-arrow-down" style="float: right;"></i></button>
<div class="panel">
    <ol>
        <li>Pilih menu TRANSFER</li>
        <li>Pilih menu VIRTUAL ACCOUNT</li>
        <li>Masukkan nomor VIRTUAL ACCOUNT yang tertera pada halaman konfirmasi</li>
        <li>Masukkan jumlah pembayaran sesuai dengan yang ditagihkan dalam halaman konfirmasi</li>
        <li>Silahkan masukkan nomor referensi apabila diperlukan, lalu tekan BENAR</li>
        <li>Pilih YA untuk menyetujui pembayaran tersebut</li>
    </ol>
</div>
<button class="accordion" >Pembayaran VA Melalui Maybank Internet Banking <i class="fa fa-arrow-down" style="float: right;"></i></button>
<div class="panel">
    <ol>
        <li>Silahkan login Internet Banking dari Maybank</li>
        <li>Pilih menu Rekening dan Transaksi</li>
        <li>Kemudian pilih Maybank Virtual Account</li>
        <li>Masukkan nomor rekening dengan nomor Virtual Account Anda : <b><?php echo $trxid ?></b></li>
        <li>Masukkan jumlah pembayaran sesuai dengan yang ditagihkan dalam halaman konfirmasi</li>
        <li>Masukkan SMS Token (TAC) dan klik Setuju</li>
    </ol>
</div>
<button class="accordion" >Pembayaran VA Melalui ATM Bank lain <i class="fa fa-arrow-down" style="float: right;"></i></button>
<div class="panel">
    <ol>
        <li>Pilih menu TRANSFER ANTAR BANK </li>
        <li>Pilih Maybank sebagai bank tujuan atau dengan memasukkan kode bank Maybank “016” diikuti dengan 16 digit nomor VIRTUAL ACCOUNT yang tertera pada halaman konfirmasi</li>
        <li>Masukkan jumlah pembayaran sesuai dengan yang ditagihkan dalam halaman konfirmasi</li>
        <li>Konfirmasikan transaksi anda pada halaman berikutnya. Apabila benar tekan BENAR untuk mengeksekusi transaksi</li>
    </ol>
</div>
<?php
break;
case '400':
?>
<button class="accordion" >Pembayaran Via Aplikasi <i class="fa fa-arrow-down" style="float: right;"></i></button>
<div class="panel" style="display: block;">
  <p>
    <img src='<?php echo $srv."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/mocash.png" ; ?>' alt="How">
</p>
</div>
<button class="accordion" >Pembayaran Via SMS <i class="fa fa-arrow-down" style="float: right;"></i></button>
<div class="panel">
    <center>
        <p>
            Lakukan pembayaran dengan cara mengirim SMS ke 9123, ketik: BAYAR MD (spasi) STORE_ID
            (spasi) AMOUNT (spasi) ORDER_ID (spasi) PIN atau BAYAR MD 1902291 (spasi) 0 (spasi)
            <?php echo $trxid ?> (spasi) (PIN ANDA)
        </p>
    </center>
</div>
<?php
break;
case '706':
?>
<button class="accordion" >Tata Cara Membayar Melalui Indomaret <i class="fa fa-arrow-down" style="float: right;"></i></button>
<div class="panel" style="display: block;">
    <ol>
        <li>Catat dan simpan kode pembayaran Indomaret anda, yaitu : <b><?php echo $trxid?></b></li>
        <li>Tunjukan kode pembayaran ke kasir Indomaret terdekat dan lakukan pembayaran senilai <b><?php echo $currency." ".number_format($total).".00" ?></b></li>
        <li>Simpan bukti pembayaran yang sewaktu-waktu diperlukan jika terjadi kendala transaksi</li>
    </ol>
</div>
<?php
break;
case '707':
?>
<button class="accordion menu-item-object-page" >Pembayaran Melalui Alfamart <i class="fa fa-arrow-down" style="float: right;"></i></button>
<div class="panel" style="display: block;">
    <ol>
        <li>Catat dan simpan kode pembayaran Alfamart Anda, yaitu : <?php echo $trxid ?>.</li>
        <li>Datangi kasir Alfamart terdekat dan beritahukan pada kasir bahwa Anda ingin melakukan pembayaran "<?php echo $merchant ?>".</li>
        <li>Beritahukan kode pembayaran Alfamart Anda pada kasir dan silahkan lakukan pembayaran Anda senilai <?php echo $currency." ".number_format($total).".00" ?>.</li>
        <li>Simpan struk pembayaran Anda sebagai tanda bukti pembayaran yang sah.</li>
    </ol>
</div>
<?php
break;
case '703':
?>
<button class="accordion" style="display: block;">Tata Cara Membayar Melalui ATM <i class="fa fa-arrow-down" style="float: right;"></i></button>
<div class="panel">
    <ol>
        <li>Catat kode pembayaran yang anda dapat</li>
        <li>Gunakan ATM Mandiri untuk menyelesaikan pembayaran</li>
        <li>Masukkan PIN anda</li>
        <li>Pilih 'Bayar/Beli' lalu pilih 'Lainnya'</li>
        <li>Cari pilihan MULTI PAYMENT</li>
        <li>Masukkan Kode Perusahaan <b><?php echo $mid ?></b></li>
        <li>Masukkan Kode Pelanggan <b><?php echo $trxid ?></b></li>
        <li>Pilih Tagihan Anda jika sudah sesuai tekan YA</li>
        <li>Konfirmasikan tagihan anda apakah sudah sesuai lalu tekan YA</li>
        <li>Harap Simpan Struk Transaksi yang anda dapatkan</li>
    </ol>
</div>
<button class="accordion" >Tata Cara Membayar Melalui Mandiri Internet Banking <i class="fa fa-arrow-down" style="float: right;"></i></button>
<div class="panel">
    <ol>
        <li>Pada Halaman Utama pilih submenu Lain-lain di bawah menu Pembayaran</li>
        <li>Cari Penyedia Jasa 70009 MitraPay</li>
        <li>Isi Nomor Pelanggan yang anda dapatkan</li>
        <li>Masukkan Jumlah Pembayaran sesuai dengan Jumlah Tagihan anda</li>
        <li>Pilih LANJUTKAN</li>
        <li>Transaksi selesai, jika perlu CETAK hasil transaksi anda</li>
    </ol>
</div>
<?php
break;
case '711':
?>
<button class="accordion" style="display: block;">Pembayaran melalui ShopeePay <i class="fa fa-arrow-down" style="float: right;"></i></button>
<div class="panel">
    <ol>
        <li>Buka aplikasi Shopee</li>
        <li>Klik logo “Scan”</li>
        <li>Scan QR Code</li>
        <li>Klik tombol “Bayar Sekarang”</li>
    </ol>
</div>
<button class="accordion" >Pembayaran melalui Mobile Banking atau E-Money lainnya <i class="fa fa-arrow-down" style="float: right;"></i></button>
<div class="panel">
    <ol>
        <li>Buka aplikasi mobile banking atau e-money</li>
        <li>Klik logo “Pay” atau “Scan”</li>
        <li>Scan QR Code</li>
        <li>Klik tombol “Pay” atau “Bayar”</li>
    </ol>
</div>
<?php
break;
default:
            # code...
break;
}
}

function get_plain_guide($ch,$trxid,$merchant,$mid,$currency,$total){
    switch ($ch) {
        case '800':
        ?>
        <h3>
            Tata Cara Membayar Melalui ATM BRI
        </h3>
        <ol>
            <li>
                Nasabah melakukan pembayaran melalui ATM Bank BRI
            </li>
            <li>
                Pilih Menu Transaksi Lain
            </li>
            <li>
                Pilih Menu Pembayaran
            </li>
            <li>
                Pilih Menu Lainnya
            </li>
            <li>
                Pilih Menu BRIVA
            </li>
            <li>
                Masukan 16 digit Nomor Virtual Account :
                <?php echo $trxid ?>
                .
            </li>
            <li>
                Proses Pembayaran (Ya/Tidak)
            </li>
            <li>
                Harap Simpan Struk Transaksi yang anda dapatkan
            </li>
        </ol>
        <h3>
            Tata Cara Membayar Melalui Mobile Banking BRI 
        </h3>
        <ol>
            <li>
                Nasabah melakukan pembayaran melalui Mobile/SMS Banking BRI
            </li>
            <li>
                Nasabah memilih Menu Pembayaran melalui Menu Mobile/SMS Banking BRI
            </li>
            <li>
                Nasabah memilih Menu BRIVA
            </li>
            <li>
                Masukan 16 digit Nomor Virtual Account : 
                <?php echo $trxid ?>
            </li>
            <li>
                Masukan Jumlah Pembayaran sesuai Tagihan
            </li>
            <li>
                Masukan PIN Mobile/SMS Banking BRI
            </li>
            <li>
                Nasabah mendapat Notifikasi Pembayaran
            </li>
        </ol>
        <h3>
            Tata Cara Membayar Melalui Internet Banking BRI 
        </h3>
        <ol>
            <li>
                Nasabah melakukan pembayaran melalui Internet Banking BRI
            </li>
            <li>
                Nasabah memilih Menu Pembayaran
            </li>
            <li>
                Nasabah memilih Menu BRIVA
            </li>
            <li>
                Masukan Kode Bayar dengan 16 digit Nomor Virtual Account : 
                <?php echo $trxid ?>
                .
            </li>
            <li>
                Masukan Password Internet Banking BRI
            </li>
            <li>
                Masukan mToken Internet Banking BRI
            </li>
            <li>
                Nasabah mendapat Notifikasi Pembayaran
            </li>
        </ol>
        <h3>
            Tata Cara Membayar Melalui ATM Bank Lain 
        </h3>
        <ol>
            <li>
                Nasabah melakukan pembayaran melalui ATM Bank Lain yang dimiliki Nasabah melalui Menu Transfer Antar Bank
            </li>
            <li>
                Masukan Kode Bank Tujuan : BRI (Kode Bank : 002) + Nomor Virtual Account : 
                <?php echo $trxid ?>
                .
            </li>
            <li>
                Masukan Jumlah Pembayaran sesuai Tagihan
            </li>
            <li>
                Proses Pembayaran (Ya/Tidak)
            </li>
            <li>
                Masukan Password Internet Banking BRI
            </li>
            <li>
                Masukan mToken Internet Banking BRI
            </li>
            <li>
                Harap Simpan Struk Transaksi yang anda dapatkan
            </li>
        </ol>
        <?php
        break;
        case '303':
        ?>
        <h3>
            Tata Cara Membayar 
        </h3>
        <ol>
            <li>
                Ketik *123*120# dari handphone Anda, lalu tekan OK/YES
            </li>
            <li>
                Setelah muncul menu transaksi XL Tunai, ketik 4 (pilihan Belanja Online)
            </li>
            <li>
                Ketik 1 (Lanjut) lalu Kirim
            </li>
            <li>
                Masukkan kode merchant 
                <?php echo $merchant ?>
                <b>
                    <u>
                        <?php echo $mid ?>
                    </u>
                </b>
                lalu Kirim
            </li>
            <li>
                Masukkan Nomor Pesanan sesuai dengan yang tertera pada laman TERIMA KASIH, lalu Kirim.
            </li>
            <li>
                Jika pembayaran berhasil, Anda akan menerima notifikasi pembayaran berhasil melalui SMS.
            </b>
        </li>
    </ol>
    <?php
    break;
    case '802':
    ?>
    <h3>
        Tata Cara Membayar Melalui ATM
    </h3>
    <ol>
        <li>
            Catat kode pembayaran yang anda dapat
        </li>
        <li>
            Gunakan ATM Mandiri untuk menyelesaikan pembayaran
        </li>
        <li>
            Masukkan PIN anda
        </li>
        <li>
            Pilih 'Bayar/Beli'
        </li>
        <li>
            Cari pilihan MULTI PAYMENT
        </li>
        <li>
            Masukkan Kode Perusahaan 
            <b>
                88308
            </b>
        </li>
        <li>
            Masukkan Kode Pelanggan 
            <b>
                <?php echo $trxid ?>
            </b>
        </li>
        <li>
            Masukkan Jumlah Pembayaran sesuai dengan Jumlah Tagihan anda kemudian tekan 'Benar'
        </li>
        <li>
            Pilih Tagihan Anda jika sudah sesuai tekan YA
        </li>
        <li>
            Konfirmasikan tagihan anda apakah sudah sesuai lalu tekan YA
        </li>
        <li>
            Harap Simpan Struk Transaksi yang anda dapatkan
        </li>
    </ol>
    <h3>
        Tata Cara Membayar Melalui Internet Banking Mandiri 
    </h3>
    <ol>
        <li>
            Pada Halaman Utama pilih menu BAYAR
        </li>
        <li>
            Pilih submenu MULTI PAYMENT
        </li>
        <li>
            Cari Penyedia Jasa 'FASPAY'
        </li>
        <li>
            Masukkan Kode Pelanggan 
            <b>
                <?php echo $trxid ?>
            </b>
        </li>
        <li>
            Masukkan Jumlah Pembayaran sesuai dengan Jumlah Tagihan anda
        </li>
        <li>
            Pilih LANJUTKAN
        </li>
        <li>
            Pilih Tagihan Anda jika sudah sesuai tekan LANJUTKAN
        </li>
        <li>
            Transaksi selesai, jika perlu CETAK hasil transaksi anda
        </li>
    </ol>
    <h3>
        Pembayaran melalui ATM Prima 
    </h3>
    <ol>
        <li>
            Masukkan PIN
        </li>
        <li>
            Pilih menu TRANSAKSI LAINNYA
        </li>
        <li>
            Pilih menu KE REK BANK LAIN
        </li>
        <li>
            Masukkan kode sandi Bank Mandiri (008) kemudian tekan BENAR
        </li>
        <li>
            Masukkan nomor VIRTUAL ACCOUNT yang tertera pada halaman konfirmasi, dan tekan BENAR
        </li>
        <li>
            Masukkan jumlah pembayaran sesuai dengan yang ditagihkan dalam halaman konfirmasi
        </li>
        <li>
            Pilih BENAR untuk menyetujui transaksi tersebut
        </li>
    </ol>
    <h3>
        Pembayaran melalui ATM Bersama 
    </h3>
    <ol>
        <li>
            Masukkan PIN
        </li>
        <li>
            Pilih menu TRANSAKSI
        </li>
        <li>
            Pilih menu KE REK BANK LAIN
        </li>
        <li>
            Masukkan kode sandi Bank Mandiri (008) diikuti dengan nomor VIRTUAL ACCOUNT yang tertera pada halaman konfirmasi, dan tekan BENAR
        </li>
        <li>
            Masukkan jumlah pembayaran sesuai dengan yang ditagihkan dalam halaman konfirmasi
        </li>
        <li>
            Pilih BENAR untuk menyetujui transaksi tersebut
        </li>
    </ol>
    <h3>
        Pembayaran Mandiri Virtual Account dengan Mandiri Online 
    </h3>
    <ol>
        <li>
            Login Mandiri Online dengan memasukkan username dan password
        </li>
        <li>
            Pilih menu PEMBAYARAN
        </li>
        <li>
            Pilih menu MULTI PAYMENT 
        </li>
        <li>
            Cari Penyedia Jasa 'FASPAY'
        </li>
        <li>
            Masukkan Nomor Virtual Account 
            <b>
                <?php echo $trxid ?>
            </b>
            dan nominal yang akan dibayarkan, lalu pilih Lanjut
        </li>
        <li>
            Setelah muncul tagihan, pilih Konfirmasi
        </li>
        <li>
            Masukkan PIN/ challange code token
        </li>
        <li>
            Transaksi selesai, simpan bukti bayar anda
        </li>
    </ol>
    <?php
    break;
    case '818': ?>
    <h3>
        Pembayaran Melalui Menu Transfer Mesin ATM 
    </h3>
    <ol>
        <small>
            <li>
                Pilih “Transfer” 
            </li>
            <li>
               Pilih “Rekening Bank Sinarmas” 
           </li>
           <li>
               Pilih “Rekening Nasabah Lain” 
           </li>
           <li>
               Masukkan kode Virtual Account + No. Pelanggan Contoh : 8856996104265376
           </li>
           <li>
               Tagihan akan muncul secara otomatis atau masukkan jumlah nominal yang akan dibayarkan 
           </li>
           <li>
               Pastikan nama penerima dan jumlah sesuai dengan yang akan dibayarkan
           </li>
           <li>
            Jika informasi sudah benar, pilih BENAR
        </li>
    </ol>
</small>
</ol>
<h3>
    Pembayaran Melalui Menu Transfer pada Internet Banking 
</h3>
<ol>
    <small>
        <li>
           Pilih “Transfer Dana” 
       </li>
       <li>
           Pilih “Transfer Bank Sinarmas” 
       </li>
       <li>
           Masukkan kode Virtual Account + No. Pelanggan Contoh : 8856996104265376 
       </li>
       <li>
           Tagihan akan muncul secara otomatis atau masukkan jumlah nominal yang akan dibayarkan 
       </li>
       <li>
           Pastikan nama penerima dan jumlah sesuai dengan yang akan dibayarkan 
       </li>
       <li>
           Silahkan masukkan Nomor Token atau SMS Token Anda
       </li>
   </small>
</ol>
<h3>
    Pembayaran Melalui Mesin ATM Bank Lain (ATM Bersama, ALTO, Prima) 
</h3>
<ol>
    <small>
        <li>
           Masuk ke menu “Layanan Transfer” 
       </li>
       <li>
        Lalu pilih “Transfer Rek. Bank Lain” 
    </li>
    <li>
        Masukkan kode sandi Bank Sinarmas (153) terlebih dahulu Masukkan 153 + 8MMM + No. Pelanggan Contoh : 8856996104265376
    </li>
    <li>
        Tagihan akan muncul secara otomatis atau masukkan jumlah nominal yang akan dibayarkan 
    </li>
    <li>
        Pastikan nama penerima dan jumlah sesuai dengan yang akan dibayarkan
    </li>
</small>
</ol>
<h3>
    Cara Pembayaran Melalui Menu Pembayaran pada Mesin ATM 
</h3>
<ol>
    <small>
        <li>
            Pilih “Pembayaran” 
        </li>
        <li>
           Pilih “Layar Berikutnya” 
       </li>
       <li>
           Pilih “Virtual Account” 
       </li>
       <li>
           Masukkan kode Virtual Account + No. Pelanggan Contoh : 8856996104265376 
       </li>
       <li>
           Tagihan akan muncul secara otomatis atau masukkan jumlah nominal yang akan dibayarkan 
       </li>
       <li>
           Pastikan nama penerima dan jumlah sesuai dengan yang akan dibayarkan
       </li>
   </small>
</ol>
<h3>
    Cara Pembayaran Melalui Menu Pembayaran pada Internet Banking 
</h3>
<ol>
    <small>
        <li>
            Pilih “Pembayaran/Pembelian” 
        </li>
        <li>
           Pilih “Virtual Account” 
       </li>
       <li>
           Masukkan kode Virtual Account + No. Pelanggan pada kolom IPDEL Contoh : 8856996104265376 
       </li>
       <li>
           Tagihan akan muncul secara otomatis 
       </li>
       <li>
           Pastikan nama penerima dan jumlah sesuai dengan yang akan dibayarkan
       </li>
   </small>
</ol>
<?php
break;
case '825': ?>
<h3>
    Pembayaran VA melalui ATM CIMB NIAGA 
</h3>
<ol>
    <small>
        <li>
            Masukan kartu ATM dan PIN CIMB Niaga Anda
        </li>
        <li>
            Pilih Menu Pembayaran
        </li>
        <li>
            Pilih Virtual Account
        </li>
        <li>
            Masukkan NOMOR VIRTUAL ACCOUNT
        </li>
        <li>
            Muncul nama dan nominal billing di layar konfirmasi
        </li>
        <li>
            Pilih OK untuk payment
        </li>
    </small>
</ol>
<h3>
    Pembayaran VA melalui ATM BERSAMA/PRIMA/BANK LAIN
</h3>
<ol>
    <small>
        <li>
            Masukan kartu ATM dan PIN Anda
        </li>
        <li>
            Masuk ke menu TRANSFER/TRANSFER Online
        </li>
        <li>
            Pilih Bank tujuan -&gt; Bank CIMB Niaga (kode bank: 022)
        </li>
        <li>
            Masukkan nomor Virtual Account Anda
        </li>
        <li>
            Masukkan jumlah pembayaran sesuai tagihan
        </li>
        <li>
            Ikuti instruksi untuk menyelesaikan transaksi
        </li>
    </small>
</ol>
<h3>
    Pembayaran VA melalui OCTO Clicks
</h3>
<ol>
    <small>
        <li>
            Login ke OCTO Clicks
        </li>
        <li>
            Pilih menu Pembayaran Tagihan
        </li>
        <li>
            Pilih kategori Mobile Rekening Virtual
        </li>
        <li>
            Masukkan nomor Virtual Account Anda
        </li>
        <li>
            Tekan tombol 'lanjut untuk verifikasi detail'
        </li>
        <li>
            Tekan tombol 'kirim OTP untuk lanjut'
        </li>
        <li>
            Masukkan OTP yang dikirimkan ke nomor HP anda
        </li>
        <li>
            Tekan tombol 'Konfirmasi'
        </li>
    </small>
</ol>
<h3>
    Pembayaran VA melalui Internet Banking Bank Lain
</h3>
<ol>
    <small>
        <li>
            Login Ke Internet Banking
        </li>
        <li>
            Pilih menu Transfer ke Bank Lain Online
        </li>
        <li>
            Pilih bank tujuan Bank CIMB Niaga (kode bank: 022)
        </li>
        <li>
            Masukkan nomor Virtual Account Anda
        </li>
        <li>
            Masukan jumlah amount sesuai tagihan
        </li>
        <li>
            Ikuti instruksi untuk menyelesaikan transaksi
        </li>
    </small>
</ol>
<h3>
    Pembayaran VA melalui OCTO MOBILE
</h3>
<ol>
    <small>
        <li>
            Login ke Octo Mobile
        </li>
        <li>
            Pilih menu TRANSFER &gt; Transfer to Other CIMB Niaga Account
        </li>
        <li>
            Pilih rekening sumber anda: CASA atau Rekening Ponsel
        </li>
        <li>
            Masukkan nomor Virtual Account Anda pada kolom Transfer To
        </li>
        <li>
            Masukkan jumlah amount sesuai tagihan
        </li>
        <li>
            Ikuti instruksi untuk menyelesaikan transaksi
        </li>
    </small>
</ol>
<h3>
    Pembayaran VA melalui EDC
</h3>
<ol>
    <small>
        <li>
            Pada menu EDC pilih menu ‘Virtual Account’ menggunakan kursor
        </li>
        <li>
            Pilih ‘Pembayaran Tagihan VA’ dengan menggunakan tombol kursor
        </li>
        <li>
            Kemudian masukkan / gesekkan kartu CIMB Niaga
        </li>
        <li>
            Konfirmasi kartu jika ingin melanjutkan, Pilih YES atau tekan tombol ENTER
        </li>
        <li>
            Masukkan nomor virtual account
        </li>
        <li>
            Kemudian pilih jenis Rekening anda dengan menggunakan tombol angka 1 atau 2, lalu tekan ENTER
        </li>
        <li>
            Ikuti instruksi untuk menyelesaikan transaksi
        </li>
    </small>
</ol>
<?php
break;
case '402':
?>
<h3>
    Pembayaran Melalui ATM Permata 
</h3>
<ol>
    <li>
        Masukkan PIN
    </li>
    <li>
        Pilih menu TRANSAKSI LAINNYA
    </li>
    <li>
        Pilih menu PEMBAYARAN
    </li>
    <li>
        Pilih menu PEMBAYARAN LAINNYA
    </li>
    <li>
        Pilih menu VIRTUAL ACCOUNT
    </li>
    <li>
        Masukkan nomor VIRTUAL ACCOUNT yang tertera pada halaman konfirmasi, dan tekan BENAR
    </li>
    <li>
        Pilih rekening yang menjadi sumber dana yang akan didebet, lalu tekan YA untuk konfirmasi transaksi
    </li>
</ol>
<h3>
    Pembayaran melalui ATM Prima 
</h3>
<ol>
    <li>
        Masukkan PIN
    </li>
    <li>
        Pilih menu TRANSAKSI LAINNYA
    </li>
    <li>
        Pilih menu KE REK BANK LAIN
    </li>
    <li>
        Masukkan kode sandi Bank Permata (013) kemudian tekan BENAR
    </li>
    <li>
        Masukkan nomor VIRTUAL ACCOUNT yang tertera pada halaman konfirmasi, dan tekan BENAR
    </li>
    <li>
        Masukkan jumlah pembayaran sesuai dengan yang ditagihkan dalam halaman konfirmasi
    </li>
    <li>
        Pilih BENAR untuk menyetujui transaksi tersebut
    </li>
</ol>
<h3>
    Pembayaran melalui ATM Bersama 
</h3>
<ol>
    <li>
        Masukkan PIN
    </li>
    <li>
        Pilih menu TRANSAKSI
    </li>
    <li>
        Pilih menu KE REK BANK LAIN
    </li>
    <li>
        Masukkan kode sandi Bank Permata (013) diikuti dengan nomor VIRTUAL ACCOUNT yang tertera pada halaman konfirmasi, dan tekan BENAR
    </li>
    <li>
        Masukkan jumlah pembayaran sesuai dengan yang ditagihkan dalam halaman konfirmasi
    </li>
    <li>
        Pilih BENAR untuk menyetujui transaksi tersebut
    </li>
</ol>
<h3>
    Pembayaran Melalui Permata Mobile 
</h3>
<ol>
    <li>
        Buka aplikasi PermataMobile Internet (Android/iPhone)
    </li>
    <li>
        Masukkan User ID & Password
    </li>
    <li>
        Pilih Pembayaran Tagihan
    </li>
    <li>
        Pilih Virtual Account
    </li>
    <li>
        Masukkan 16 digit nomor Virtual Account yang tertera pada halaman konfirmasi
    </li>
    <li>
        Masukkan nominal pembayaran sesuai dengan yang ditagihkan
    </li>
    <li>
        Muncul Konfirmasi pembayarann
    </li>
    <li>
        Masukkan otentikasi transaksi/token
    </li>
    <li>
        Transaksi selesai
    </li>
</ol>
<h3>
    Pembayaran Melalui Permata Net 
</h3>
<ol>
    <li>
        Buka website PermataNet: 
        <a href="https://new.permatanet.com">
            https://new.permatanet.com
        </a>
    </li>
    <li>
        Masukkan User ID & Password
    </li>
    <li>
        Pilih Pembayaran Tagihan
    </li>
    <li>
        Pilih Virtual Account
    </li>
    <li>
        Masukkan 16 digit nomor Virtual Account yang tertera pada halaman konfirmasi
    </li>
    <li>
        Masukkan nominal pembayaran sesuai dengan yang ditagihkan
    </li>
    <li>
        Muncul Konfirmasi pembayarann
    </li>
    <li>
        Masukkan otentikasi transaksi/token
    </li>
    <li>
        Transaksi selesai
    </li>
</ol>
<?php
break;
case '801':
?>
<h3>
    Tata Cara Membayar Melalui ATM BNI 
</h3>
<ol>
    <li>
        Nasabah melakukan pembayaran melalui ATM Bank BNI
    </li>
    <li>
        Pilih Menu Lainnya
    </li>
    <li>
        Pilih Menu Transfer
    </li>
    <li>
        Pilih Menu Rekening Tabungan
    </li>
    <li>
        Pilih Menu Ke Rekening BNI
    </li>
    <li>
        Masukan 16 digit Nomor Virtual Account 
        <b>
            <?php echo $trxid ?>
        </b>
    </li>
    <li>
        Masukan Nominal Transfer
    </li>
    <li>
        Konfirmasi Pemindahbukuan
    </li>
    <li>
        Transaksi Selesai. Harap Simpan Struk Transaksi yang anda dapatkan
    </li>
</ol>
<h3>
    Tata Cara Membayar Melalui SMS Banking BNI 
</h3>
<ol>
    <li>
        Nasabah melakukan pembayaran melalui SMS Banking BNI
    </li>
    <li>
        Pilih Menu Transfer
    </li>
    <li>
        Masukan 16 digit Nomor Virtual Account 
        <b>
            <?php echo $trxid ?>
        </b>
    </li>
    <li>
        Masukan Jumlah Pembayaran. Kemudian Proses
    </li>
    <li>
        Akan Muncul Popup dan kemudian Pilih Yes lalu Send
    </li>
    <li>
        Anda akan mendapatkan SMS konfirmasi dari BNI
    </li>
    <li>
        Reply SMS dengan ketik pin digit ke 2 & 3
    </li>
    <li>
        Transaksi Berhasil
    </li>
</ol>
<br>
Atau bisa juga langsung mengetik sms dan kirim ke 3346 dengan format
<br>
<ol>
    <li>
        <b>
            TRF[SPASI]NOMOR VA BNI[SPASI]NOMINAL
        </b>
    </li>
    <li>
        Anda akan mendapatkan SMS konfirmasi dari BNI
    </li>
    <li>
        Reply SMS dengan ketik pin digit ke 2 & 3
    </li>
    <li>
        Transaksi Berhasil
    </li>
</ol>
<h3>
    Internet Banking BNI 
</h3>
<ol>
    <li>
        Nasabah melakukan pembayaran melalui Internet Banking BNI
    </li>
    <li>
        Ketik alamat 
        <a href="https://ibank.bni.co.id">
            https://ibank.bni.co.id
        </a>
    </li>
    <li>
        Masukkan User ID dan Password
    </li>
    <li>
        Klik menu 
        <b>
            TRANSFER
        </b>
        kemudian pilih 
        <b>
            TAMBAH REKENING FAVORIT
        </b>
        . Jika menggunakan Desktop/PC untuk menambah rekening pada menu 
        <b>
            Transaksi
        </b>
        kemudian 
        <b>
            Atur Rekening Tujuan
        </b>
        lalu 
        <b>
            Tambah Rekening Tujuan
        </b>
    </li>
    <li>
        Masukan Nama dan Kode Bayar dengan 16 digit Nomor Virtual Account 
        <b>
            <?php echo $trxid ?>
        </b>
    </li>
    <li>
        Masukan Kode Otentikasi Token
    </li>
    <li>
        Nomor Rekening Tujuan Berhasil Ditambahkan
    </li>
    <li>
        Kembali ke menu TRANSFER. Pilih TRANSFER ANTAR REKENING BNI, kemudian pilih rekening tujuan
    </li>
    <li>
        Pilih Rekening Debit dan ketik nominal, lalu masukkan kode otentikasi token
    </li>
    <li>
        Transfer Anda Telah Berhasil
    </li>
</ol>
<h3>
    Mobile Banking BNI 
</h3>
<ol>
    <li>
        Akses BNI Mobile Banking dari handphone kemudian masukkan User ID dan Password
    </li>
    <li>
        Pilih menu Transfer
    </li>
    <li>
        Pilih Antar Rekening BNI kemudian Input Rekening Baru
    </li>
    <li>
        Masukkan nomor Rekening Debit
    </li>
    <li>
        Masukkan nomor Rekening Tujuan dengan 16 digit Nomor Virtual Account 
        <b>
            <?php echo $trxid ?>
        </b>
    </li>
    <li>
        Masukkan jumlah pembayaran. Klik Benar
    </li>
    <li>
        Konfirmasi transaksi dan masukkan Password Transaksi
    </li>
    <li>
        Transaksi Anda Telah Berhasil
    </li>
</ol>
<h3>
    ATM Bank Lain 
</h3>
<ol>
    <li>
        Nasabah melakukan pembayaran melalui ATM Bank Lain
    </li>
    <li>
        Pilih menu Transaksi Lainnya
    </li>
    <li>
        Pilih menu Transfer
    </li>
    <li>
        Pilih Rekening BNI Lain
    </li>
    <li>
        Masukkan Kode Bank BNI (009) dan Pilih Benar
    </li>
    <li>
        Masukkan jumlah pembayaran
    </li>
    <li>
        Masukkan 16 digit Nomor Virtual Account 
        <b>
            <?php echo $trxid ?>
        </b>
    </li>
    <li>
        Pilih Rekening yang akan di debit
    </li>
    <li>
        Konfirmasi Pembayaran
    </li>
    <li>
        Transaksi Selesai. Harap Simpan Struk Transaksi yang anda dapatkan
    </li>
</ol>
<?php
break;
case '708':
?>
<h3>
    Pembayaran Melalui ATM Danamon 
</h3>
<ol>
    <li>
        Masuk ke menu Pembayaran ->
        Lainnya ->
        Virtual Account 
    </li>
    <li>
        Masukkan 16 digit nomor Virtual Account 
    </li>
    <li>
        Periksa jumlah tagihan dan konfirmasi pembayaran. 
    </li>
</ol>
<h3>
    Transfer dari Bank Lain 
</h3>
<ol>
    <li>
        Transfer melalui Bank Lain yang tergabung dalam jaringan ATM Bersama, ALTO dan Prima.
    </li>
    <li>
        Masukkan kode Bank Danamon (011) dan 16 digit nomor Virtual Account di rekening tujuan.
    </li>
    <li>
        Masukkan nominal transfer sesuai tagihan.
    </li>
</ol>
<?php
break;
case '702':
?>
<h3>
    Tata Cara Membayar Melalui ATM/ANT/SETAR-Setor Tarik 
</h3>
<b>
    Langkah-langkah transaksi BCA Virtual Account melalui ATM/ANT/SETAR-Setor Tarik:
</b>
<br>
<ol>
    <li>
        Pilih menu Transfer – Ke Rek BCA Virtual Account
    </li>
    <li>
        Masukkan Nomor BCA Virtual Account, lalu pilih Benar
    </li>
    <li>
        Pilih menu “Ke Rek BCA Virtual Account”
    </li>
    <li>
        Layar ATM akan menampilkan konfirmasi transaksi:
        <br>
        <ul>
            <li>
                Pilih Ya bila setuju, atau 
            </li>
            <li>
                Masukkan jumlah transfer, lalu pilih Benar. Layar ATM akan kembali menampilkan konfirmasi jumlah pembayaran, pilih Ya bila ingin membayar
            </li>
        </ul>
    </li>
    <li>
        Ikuti langkah selanjutnya sampai transaksi selesai
    </li>
</ol>
<h3>
    KlikBCA Individu (Full Site dan versi Smartphone) 
</h3>
<b>
    Langkah-langkah transaksi BCA Virtual Account melalui KlikBCA Individu: 
</b>
<br>
<ol>
    <li>
        Pilih Menu Transfer Dana – Transfer ke BCA Virtual Account
    </li>
    <li>
        Masukkan nomor BCA Virtual Account, atau pilih Dari Daftar Transfer 
    </li>
    <li>
        Akan tampil konfirmasi transaksi: 
        <br>
        <ul>
            <li>
                Masukkan jumlah nominal transfer dan berita, atau 
            </li>
            <li>
                Masukkan berita
            </li>
        </ul>
    </li>
    <li>
        Ikuti langkah selanjutnya sampai transaksi selesai 
    </li>
</ol>
<h3>
    KlikBCA Bisnis 
</h3>
<b>
    Langkah-langkah transaksi BCA Virtual Account melalui KlikBCA Bisnis: 
</b>
<br>
<ul>
    <li>
        Daftar Transfer: 
        <br>
        <ol>
            <li>
                Pilih menu Daftar Transfer - Tambah, pilih Ke BCA Virtual Account
            </li>
            <li>
                Masukkan nomor BCA Virtual Account
            </li>
            <li>
                Ikuti langkah selanjutnya sampai selesai 
            </li>
        </ol>
    </li>
    <li>
        Transfer Dana: 
        <br>
        <li>
            Pilih menu Transfer Dana – ke BCA Virtual Account
        </li>
        <li>
            Pilih nomor rekening yang akan didebet dan pilih nomor BCA Virtual Account, lalu lanjut 
        </li>
        <li>
            Akan tampil konfirmasi transaksi: 
            <br>
            <ul>
                <li>
                    Masukkan jumlah nominal transfer dan berita, atau
                </li>
                <li>
                    Masukkan berita
                </li>
            </ul>
        </li>
        <li>
            Ikuti langkah selanjutnya sampai transaksi selesai
        </li>
    </li>
    <li>
        Otorisasi Transaksi: 
        <br>
        <ul>
            <li>
                Pilih menu Transfer Dana - Otorisasi Transaksi Tergantung single/multi otorisasi
            </li>
            <li>
                Untuk Single Otorisasi: 
                <br>
                <ul>
                    Login User Releaser
                    <li>
                        Tandai transaksi pada tabel Transaksi Yang Belum Diotorisasi, pilih Setuju 
                    </li>
                    <li>
                        Ikuti langkah selanjutnya sampai selesai
                    </li>
                </ul>
            </li>
            <li>
                Untuk Multi Otorisasi: 
                <br>
                <ul>
                    <li>
                        Login User Approver
                        <ol>
                            <li>
                                Tandai transaksi pada tabel Approver, pilih Setuju 
                            </li>
                        </ol>
                    </li>
                    <li>
                        Login User Releaser
                        <ol>
                            <li>
                                Tandai transaksi pada tabel Transaksi Yang Belum Diotorisasi, pilih Setuju
                            </li>
                            <li>
                                Ikuti langkah selanjutnya sampai selesai
                            </li>
                        </ol>
                    </li>
                </ul>
            </li>
        </ul>
    </li>
</ul>
</ol>
<h3>
    m-BCA (BCA Mobile) 
</h3>
<b>
    Langkah-langkah transaksi BCA Virtual Account melalui m-BCA (BCA Mobile):
</b>
<br>
<ol>
    <li>
        Pilih m-Transfer
    </li>
    <li>
        Pilih Transfer – BCA Virtual Account
    </li>
    <li>
        Pilih nomor rekening yang akan didebet
    </li>
    <li>
        Masukkan nomor BCA Virtual Account, lalu pilih OK
    </li>
    <li>
        Tampil konfirmasi nomor BCA Virtual Account dan rekening pendebetan, lalu Kirim
    </li>
    <li>
        Tampil konfirmasi pembayaran, lalu pilih OK 
        <br>
        <ul>
            <li>
                Masukkan jumlah nominal transfer dan berita, atau 
            </li>
            <li>
                Masukkan berita
            </li>
        </ul>
    </li>
    <li>
        Ikuti langkah selanjutnya sampai transaksi selesai 
    </li>
</ol>
<h3>
    m-BCA (STK) 
</h3>
<b>
    Langkah-langkah transaksi BCA Virtual Account melalui m-BCA (STK):
</b>
<br>
<ol>
    <li>
        Pilih m-BCA 
    </li>
    <li>
        Pilih m-Payment
    </li>
    <li>
        Pilih Lainnya
    </li>
    <li>
        Masukkan TVA pada Nama PT, lalu OK
    </li>
    <li>
        Masukkan nomor BCA Virtual Account pada No. Pelanggan, lalu OK
    </li>
    <li>
        Masukkan PIN m-BCA, lalu OK
    </li>
    <li>
        Pilih Pilih nomor rekening yang akan didebet, lalu lanjut
    </li>
    <li>
        Akan muncul konfirmasi pembayaran, lalu pilih OK 
        <br>
        <ul>
            <li>
                Masukkan jumlah bayar dan berita, atau 
            </li>
            <li>
                Masukkan berita
            </li>
        </ul>
    </li>
    <li>
        Ikuti langkah selanjutnya sampai transaksi selesai 
    </li>
</ol>
<?php
break;
case '408':
?>
<h3>
    Pembayaran VA Melalui Mesin ATM Maybank - Menu Pembayaran 
</h3>
<ol>
    <li>
        Pilih menu PEMBAYARAN/TOP UP PULSA
    </li>
    <li>
        Pilih menu VIRTUAL ACCOUNT
    </li>
    <li>
        Masukkan nomor VIRTUAL ACCOUNT yang tertera pada halaman konfirmasi
    </li>
    <li>
        Pilih YA untuk menyetujui pembayaran tersebut
    </li>
</ol>
<h3>
    Pembayaran VA Melalui Mesin ATM Maybank - Menu Transfer 
</h3>
<ol>
    <li>
        Pilih menu TRANSFER
    </li>
    <li>
        Pilih menu VIRTUAL ACCOUNT
    </li>
    <li>
        Masukkan nomor VIRTUAL ACCOUNT yang tertera pada halaman konfirmasi
    </li>
    <li>
        Masukkan jumlah pembayaran sesuai dengan yang ditagihkan dalam halaman konfirmasi
    </li>
    <li>
        Silahkan masukkan nomor referensi apabila diperlukan, lalu tekan BENAR
    </li>
    <li>
        Pilih YA untuk menyetujui pembayaran tersebut
    </li>
</ol>
<h3>
    Pembayaran VA Melalui Maybank Internet Banking 
</h3>
<ol>
    <li>
        Silahkan login Internet Banking dari Maybank
    </li>
    <li>
        Pilih menu Rekening dan Transaksi
    </li>
    <li>
        Kemudian pilih Maybank Virtual Account
    </li>
    <li>
        Masukkan nomor rekening dengan nomor Virtual Account Anda : 
        <b>
            <?php echo $trxid ?>
        </b>
    </li>
    <li>
        Masukkan jumlah pembayaran sesuai dengan yang ditagihkan dalam halaman konfirmasi
    </li>
    <li>
        Masukkan SMS Token (TAC) dan klik Setuju
    </li>
</ol>
<h3>
    Pembayaran VA Melalui ATM Bank lain 
</h3>
<ol>
    <li>
        Pilih menu TRANSFER ANTAR BANK 
    </li>
    <li>
        Pilih Maybank sebagai bank tujuan atau dengan memasukkan kode bank Maybank “016” diikuti dengan 16 digit nomor VIRTUAL ACCOUNT yang tertera pada halaman konfirmasi
    </li>
    <li>
        Masukkan jumlah pembayaran sesuai dengan yang ditagihkan dalam halaman konfirmasi
    </li>
    <li>
        Konfirmasikan transaksi anda pada halaman berikutnya. Apabila benar tekan BENAR untuk mengeksekusi transaksi
    </li>
</ol>
<?php
break;
case '400':
?>
<h3>
    Pembayaran Via Aplikasi 
</h3>
<p>
    <img src='
    <?php echo $srv."/wp-content/plugins/woocommerce-gateway-faspay/includes/assets/mocash.png" ; ?>
    ' alt="How">
</p>
</ol>
<h3>
    Pembayaran Via SMS 
</h3>
<ol>
    <center>
        <p>
            Lakukan pembayaran dengan cara mengirim SMS ke 9123, ketik: BAYAR MD (spasi) STORE_ID
            (spasi) AMOUNT (spasi) ORDER_ID (spasi) PIN atau BAYAR MD 1902291 (spasi) 0 (spasi)
            <?php echo $trxid ?>
            (spasi) (PIN ANDA)
        </p>
    </center>
</ol>
<?php
break;
case '706':
?>
<h3>
    Tata Cara Membayar Melalui Indomaret 
</h3>
<ol>
    <li>
        Catat dan simpan kode pembayaran Indomaret anda, yaitu : 
        <b>
            <?php echo $trxid?>
        </b>
    </li>
    <li>
        Tunjukan kode pembayaran ke kasir Indomaret terdekat dan lakukan pembayaran senilai 
        <b>
            <?php echo $currency." ".number_format($total).".00" ?>
        </b>
    </li>
    <li>
        Simpan bukti pembayaran yang sewaktu-waktu diperlukan jika terjadi kendala transaksi
    </li>
</ol>
<?php
break;
case '707':
?>
<h3>
    Pembayaran Melalui Alfamart 
</h3>
<ol>
    <li>
        Catat dan simpan kode pembayaran Alfamart Anda, yaitu : 
        <?php echo $trxid ?>
        .
    </li>
    <li>
        Datangi kasir Alfamart terdekat dan beritahukan pada kasir bahwa Anda ingin melakukan pembayaran "
        <?php echo $merchant ?>
        ".
    </li>
    <li>
        Beritahukan kode pembayaran Alfamart Anda pada kasir dan silahkan lakukan pembayaran Anda senilai 
        <?php echo $currency." ".number_format($total).".00" ?>
        .
    </li>
    <li>
        Simpan struk pembayaran Anda sebagai tanda bukti pembayaran yang sah.
    </li>
</ol>
<?php
break;
case '703':
?>
<h3>
    Tata Cara Membayar Melalui ATM 
</h3>
<ol>
    <li>
        Catat kode pembayaran yang anda dapat
    </li>
    <li>
        Gunakan ATM Mandiri untuk menyelesaikan pembayaran
    </li>
    <li>
        Masukkan PIN anda
    </li>
    <li>
        Pilih 'Bayar/Beli' lalu pilih 'Lainnya'
    </li>
    <li>
        Cari pilihan MULTI PAYMENT
    </li>
    <li>
        Masukkan Kode Perusahaan 
        <b>
            <?php echo $mid ?>
        </b>
    </li>
    <li>
        Masukkan Kode Pelanggan 
        <b>
            <?php echo $trxid ?>
        </b>
    </li>
    <li>
        Pilih Tagihan Anda jika sudah sesuai tekan YA
    </li>
    <li>
        Konfirmasikan tagihan anda apakah sudah sesuai lalu tekan YA
    </li>
    <li>
        Harap Simpan Struk Transaksi yang anda dapatkan
    </li>
</ol>
<h3>
    Tata Cara Membayar Melalui Mandiri Internet Banking 
</h3>
<ol>
    <li>
        Pada Halaman Utama pilih submenu Lain-lain di bawah menu Pembayaran
    </li>
    <li>
        Cari Penyedia Jasa 70009 MitraPay
    </li>
    <li>
        Isi Nomor Pelanggan yang anda dapatkan
    </li>
    <li>
        Masukkan Jumlah Pembayaran sesuai dengan Jumlah Tagihan anda
    </li>
    <li>
        Pilih LANJUTKAN
    </li>
    <li>
        Transaksi selesai, jika perlu CETAK hasil transaksi anda
    </li>
</ol>
<?php
break;
case '711':
?>
<h3>
    Pembayaran melalui ShopeePay 
</h3>
<ol>
    <li>
        Buka aplikasi Shopee
    </li>
    <li>
        Klik logo “Scan”
    </li>
    <li>
        Scan QR Code
    </li>
    <li>
        Klik tombol “Bayar Sekarang”
    </li>
</ol>
<h3>
    Pembayaran melalui Mobile Banking atau E-Money lainnya 
</h3>
<ol>
    <li>
        Buka aplikasi mobile banking atau e-money
    </li>
    <li>
        Klik logo “Pay” atau “Scan”
    </li>
    <li>
        Scan QR Code
    </li>
    <li>
        Klik tombol “Pay” atau “Bayar”
    </li>
</ol>
<?php
break;
default:
break;
}

}
?>>>>>>>> .r42
